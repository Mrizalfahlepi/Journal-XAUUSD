import { createInsertSchema } from "drizzle-zod";
import { pgTable, smallint, timestamp, varchar } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const loginAttemptsTable = pgTable("login_attempts", {
  bucketKey: varchar("bucket_key", { length: 64 }).primaryKey(),
  failedAttempts: smallint("failed_attempts").notNull().default(0),
  windowStartedAt: timestamp("window_started_at", { withTimezone: true }).notNull().defaultNow(),
  blockedUntil: timestamp("blocked_until", { withTimezone: true }),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertLoginAttemptSchema = createInsertSchema(loginAttemptsTable).omit({
  updatedAt: true,
});

export type InsertLoginAttempt = z.infer<typeof insertLoginAttemptSchema>;
export type LoginAttempt = typeof loginAttemptsTable.$inferSelect;
