import { createInsertSchema } from "drizzle-zod";
import { date, numeric, pgEnum, pgTable, timestamp, uuid } from "drizzle-orm/pg-core";
import { z } from "zod/v4";
import { journalUsersTable } from "./journal-users";

export const appearanceModeEnum = pgEnum("appearance_mode", ["system", "light", "dark"]);

export const journalProfilesTable = pgTable("journal_profiles", {
  userId: uuid("user_id")
    .primaryKey()
    .references(() => journalUsersTable.id, { onDelete: "cascade" }),
  initialBalanceUSC: numeric("initial_balance_usc", { precision: 18, scale: 4, mode: "number" }).notNull(),
  exchangeRateIDR: numeric("exchange_rate_idr", { precision: 20, scale: 4, mode: "number" }).notNull(),
  targetRate: numeric("target_rate", { precision: 10, scale: 8, mode: "number" }).notNull(),
  startDate: date("start_date", { mode: "string" }).notNull(),
  appearanceMode: appearanceModeEnum("appearance_mode").notNull().default("system"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertJournalProfileSchema = createInsertSchema(journalProfilesTable).omit({
  createdAt: true,
  updatedAt: true,
});

export type InsertJournalProfile = z.infer<typeof insertJournalProfileSchema>;
export type JournalProfile = typeof journalProfilesTable.$inferSelect;
