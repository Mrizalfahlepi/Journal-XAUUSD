import { createInsertSchema } from "drizzle-zod";
import { pgTable, text, timestamp, uniqueIndex, uuid, varchar } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const journalUsersTable = pgTable(
  "journal_users",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    name: varchar("name", { length: 60 }).notNull(),
    normalizedName: varchar("normalized_name", { length: 60 }).notNull(),
    pinHash: text("pin_hash").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
  },
  (table) => [uniqueIndex("journal_users_normalized_name_uq").on(table.normalizedName)],
);

export const insertJournalUserSchema = createInsertSchema(journalUsersTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertJournalUser = z.infer<typeof insertJournalUserSchema>;
export type JournalUser = typeof journalUsersTable.$inferSelect;
