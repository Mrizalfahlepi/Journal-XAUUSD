import { createInsertSchema } from "drizzle-zod";
import { numeric, pgTable, primaryKey, smallint, text, timestamp, uuid } from "drizzle-orm/pg-core";
import { z } from "zod/v4";
import { journalUsersTable } from "./journal-users";

export const journalEntriesTable = pgTable(
  "journal_entries",
  {
    userId: uuid("user_id")
      .notNull()
      .references(() => journalUsersTable.id, { onDelete: "cascade" }),
    dayNumber: smallint("day_number").notNull(),
    profitUSC: numeric("profit_usc", { precision: 18, scale: 4, mode: "number" }),
    note: text("note").notNull().default(""),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
  },
  (table) => [primaryKey({ columns: [table.userId, table.dayNumber] })],
);

export const insertJournalEntrySchema = createInsertSchema(journalEntriesTable).omit({
  updatedAt: true,
});

export type InsertJournalEntry = z.infer<typeof insertJournalEntrySchema>;
export type JournalEntry = typeof journalEntriesTable.$inferSelect;
