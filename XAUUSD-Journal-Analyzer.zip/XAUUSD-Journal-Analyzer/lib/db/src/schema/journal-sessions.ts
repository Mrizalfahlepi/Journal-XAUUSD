import { createInsertSchema } from "drizzle-zod";
import { index, pgTable, timestamp, uuid, varchar } from "drizzle-orm/pg-core";
import { z } from "zod/v4";
import { journalUsersTable } from "./journal-users";

export const journalSessionsTable = pgTable(
  "journal_sessions",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => journalUsersTable.id, { onDelete: "cascade" }),
    tokenHash: varchar("token_hash", { length: 64 }).notNull().unique(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("journal_sessions_user_idx").on(table.userId), index("journal_sessions_expiry_idx").on(table.expiresAt)],
);

export const insertJournalSessionSchema = createInsertSchema(journalSessionsTable).omit({
  id: true,
  createdAt: true,
});

export type InsertJournalSession = z.infer<typeof insertJournalSessionSchema>;
export type JournalSession = typeof journalSessionsTable.$inferSelect;
