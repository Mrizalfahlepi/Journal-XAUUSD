---
name: Batas responsivitas
description: Batasan visual dan fungsional untuk penyesuaian responsif aplikasi jurnal.
---

Saat merapikan responsivitas aplikasi Trading Journal, pertahankan konsep, warna, gaya, isi, dan fitur yang sudah ada.

**Why:** pengguna secara eksplisit meminta perubahan responsivitas tanpa mengubah hal-hal tersebut.

**How to apply:** fokuskan perubahan pada breakpoint, ukuran komponen, wrapping, safe area, dan ukuran target sentuh.
