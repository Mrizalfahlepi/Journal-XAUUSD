import type * as XLSX from "xlsx";
import {
  calculateJournal,
  JOURNAL_DAYS,
  type DailyEntry,
  type JournalParameters,
} from "@/domain/journal";

const SHEET_NAME = "Checklist";
const HEADER_ROW = 12;
const FIRST_DATA_ROW = 13;
const EXCEL_EPOCH_UTC = Date.UTC(1899, 11, 30);
const DAY_MS = 24 * 60 * 60 * 1000;
let xlsxModulePromise: Promise<typeof import("xlsx")> | undefined;
const HEADERS = [
  "No",
  "Tanggal",
  "Hari",
  "Profit Aktual (USC)",
  "Profit Aktual (Rp)",
  "Saldo Aktual (USC)",
  "Saldo Aktual (Rp)",
  "Profit %",
  "Tercapai?",
  "Target Profit (USC)",
  "Target Saldo (USC)",
  "Target Saldo (Rp)",
  "Catatan",
];

function loadXLSX() {
  xlsxModulePromise ??= import("xlsx");
  return xlsxModulePromise;
}

function getCellValue(
  sheet: XLSX.WorkSheet,
  address: string,
): unknown {
  return sheet[address]?.v;
}

function parseNumber(value: unknown, fallback: number): number {
  const parsed = typeof value === "number" ? value : Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function excelDateToISO(value: unknown, fallback: string): string {
  if (value instanceof Date && !Number.isNaN(value.getTime())) {
    return value.toISOString().slice(0, 10);
  }
  const serial = Number(value);
  if (!Number.isFinite(serial)) return fallback;
  return new Date(EXCEL_EPOCH_UTC + serial * DAY_MS).toISOString().slice(0, 10);
}

export async function importJournal(file: File): Promise<{
  parameters: JournalParameters;
  entries: DailyEntry[];
}> {
  const XLSX = await loadXLSX();
  const workbook = XLSX.read(await file.arrayBuffer(), { cellDates: true });
  const sheet = workbook.Sheets[SHEET_NAME];
  if (!sheet) {
    throw new Error(`Sheet "${SHEET_NAME}" tidak ditemukan di file Excel.`);
  }

  const headerValues = HEADERS.map((_, columnIndex) =>
    getCellValue(sheet, XLSX.utils.encode_cell({ r: HEADER_ROW - 1, c: columnIndex })),
  );
  if (headerValues[0] !== "No" || headerValues[3] !== "Profit Aktual (USC)") {
    throw new Error("Format kolom tidak cocok dengan workbook jurnal Checklist.");
  }

  const parameters: JournalParameters = {
    initialBalanceUSC: parseNumber(getCellValue(sheet, "C3"), 2503),
    exchangeRateIDR: parseNumber(getCellValue(sheet, "C4"), 179),
    targetRate: parseNumber(getCellValue(sheet, "C5"), 0.05),
    startDate: excelDateToISO(getCellValue(sheet, "C6"), "2026-10-01"),
  };

  const entries: DailyEntry[] = Array.from(
    { length: JOURNAL_DAYS },
    (_, index) => {
      const row = FIRST_DATA_ROW + index;
      const rawProfit = getCellValue(sheet, `D${row}`);
      const numericProfit =
        rawProfit === undefined || rawProfit === null || rawProfit === ""
          ? null
          : Number(rawProfit);
      return {
        profitUSC:
          numericProfit !== null && Number.isFinite(numericProfit)
            ? numericProfit
            : null,
        note: String(getCellValue(sheet, `M${row}`) ?? ""),
      };
    },
  );

  return { parameters, entries };
}

function excelSerial(date: string): number {
  const [year, month, day] = date.split("-").map(Number);
  return (Date.UTC(year, month - 1, day) - EXCEL_EPOCH_UTC) / DAY_MS;
}

function putFormula(
  sheet: XLSX.WorkSheet,
  address: string,
  formula: string,
  cachedValue: number | string,
  numberFormat?: string,
) {
  sheet[address] = {
    t: typeof cachedValue === "number" ? "n" : "str",
    f: formula,
    v: cachedValue,
    ...(numberFormat ? { z: numberFormat } : {}),
  };
}

export async function exportJournal(
  parameters: JournalParameters,
  entries: DailyEntry[],
): Promise<Blob> {
  const XLSX = await loadXLSX();
  const { days, summary } = calculateJournal(parameters, entries);
  const rows: (string | number | boolean | null)[][] = Array.from(
    { length: 144 },
    () => [],
  );

  rows[0][0] = "JURNAL TARGET HARIAN XAUUSD (USC) - COMPOUND GROWTH";
  rows[2][0] = "Modal awal (USC)";
  rows[2][2] = parameters.initialBalanceUSC;
  rows[2][4] = "Total profit (USC)";
  rows[2][7] = summary.totalProfitUSC;
  rows[3][0] = "Kurs: 1 USC = Rp";
  rows[3][2] = parameters.exchangeRateIDR;
  rows[3][4] = "Total profit (Rp)";
  rows[3][7] = summary.totalProfitIDR;
  rows[4][0] = "Target per hari";
  rows[4][2] = parameters.targetRate;
  rows[4][4] = "Saldo aktual (USC)";
  rows[4][7] = summary.actualBalanceUSC;
  rows[5][0] = "Tanggal mulai";
  rows[5][2] = excelSerial(parameters.startDate);
  rows[5][4] = "Saldo aktual (Rp)";
  rows[5][7] = summary.actualBalanceIDR;
  rows[6][0] = "Modal awal setara (Rp)";
  rows[6][2] = parameters.initialBalanceUSC * parameters.exchangeRateIDR;
  rows[6][4] = "Hari tercapai";
  rows[6][7] = `${summary.daysMet} dari ${summary.daysFilled} hari terisi`;
  rows[7][4] = "Posisi vs jalur target (USC)";
  rows[7][7] = summary.positionVsTargetUSC;
  rows[9][0] =
    "Isi kolom Profit Aktual (USC) dan Catatan. Semua nilai turunan dihitung otomatis.";
  rows[10][0] =
    "Hari kerja Senin-Jumat; hari libur nasional tidak dikurangi. Saldo tidak mengurangi penarikan.";
  rows[HEADER_ROW - 1] = HEADERS;

  for (let index = 0; index < JOURNAL_DAYS; index += 1) {
    const row = FIRST_DATA_ROW + index;
    const day = days[index];
    const entry = entries[index] ?? { profitUSC: null, note: "" };
    rows[row - 1] = [
      day.number,
      excelSerial(day.date),
      day.weekday,
      entry.profitUSC,
      day.profitIDR,
      day.actualBalanceUSC,
      day.actualBalanceIDR,
      day.profitPercent === null ? null : day.profitPercent / 100,
      day.targetMet === null ? null : day.targetMet ? "✔" : "✘",
      day.targetProfitUSC,
      day.targetBalanceUSC,
      day.targetBalanceIDR,
      entry.note,
    ];
  }
  rows[143][0] =
    "Baris emas menandai hari pertama Target Saldo (Rp) mencapai Rp100 juta.";

  const sheet = XLSX.utils.aoa_to_sheet(rows);
  sheet["!cols"] = [
    { wch: 7 },
    { wch: 15 },
    { wch: 13 },
    { wch: 20 },
    { wch: 20 },
    { wch: 20 },
    { wch: 20 },
    { wch: 13 },
    { wch: 15 },
    { wch: 20 },
    { wch: 20 },
    { wch: 22 },
    { wch: 42 },
  ];
  sheet["C3"].z = "#,##0.00";
  sheet["C4"].z = '"Rp" #,##0.00';
  sheet["C5"].z = "0.00%";
  sheet["C6"].z = "dd mmmm yyyy";
  sheet["H3"].z = "#,##0.00";
  sheet["H4"].z = '"Rp" #,##0.00';
  sheet["H5"].z = "#,##0.00";
  sheet["H6"].z = '"Rp" #,##0.00';

  for (let index = 0; index < JOURNAL_DAYS; index += 1) {
    const row = FIRST_DATA_ROW + index;
    const previousRow = row - 1;
    const day = days[index];
    const hasProfit = day.profitUSC !== null;
    const profit = day.profitUSC ?? 0;

    if (index === 0) {
      putFormula(sheet, `B${row}`, "=$C$6", excelSerial(day.date), "dd mmm yyyy");
      putFormula(
        sheet,
        `J${row}`,
        "=$C$3*$C$5",
        day.targetProfitUSC,
        "#,##0.00",
      );
      putFormula(
        sheet,
        `K${row}`,
        `=$C$3+J${row}`,
        day.targetBalanceUSC,
        "#,##0.00",
      );
    } else {
      putFormula(
        sheet,
        `B${row}`,
        `=WORKDAY(B${previousRow},1)`,
        excelSerial(day.date),
        "dd mmm yyyy",
      );
      putFormula(
        sheet,
        `J${row}`,
        `=K${previousRow}*$C$5`,
        day.targetProfitUSC,
        "#,##0.00",
      );
      putFormula(
        sheet,
        `K${row}`,
        `=K${previousRow}+J${row}`,
        day.targetBalanceUSC,
        "#,##0.00",
      );
    }

    putFormula(
      sheet,
      `C${row}`,
      `=CHOOSE(WEEKDAY(B${row},2),"Senin","Selasa","Rabu","Kamis","Jumat","Sabtu","Minggu")`,
      day.weekday,
    );
    putFormula(
      sheet,
      `E${row}`,
      `=IF(D${row}="","",D${row}*$C$4)`,
      hasProfit ? profit * parameters.exchangeRateIDR : "",
      '"Rp" #,##0.00',
    );
    putFormula(
      sheet,
      `F${row}`,
      `=IF(D${row}="","",$C$3+SUM(D$13:D${row}))`,
      hasProfit ? day.actualBalanceUSC! : "",
      "#,##0.00",
    );
    putFormula(
      sheet,
      `G${row}`,
      `=IF(D${row}="","",F${row}*$C$4)`,
      hasProfit ? day.actualBalanceIDR! : "",
      '"Rp" #,##0.00',
    );
    putFormula(
      sheet,
      `H${row}`,
      `=IF(D${row}="","",D${row}/(F${row}-D${row}))`,
      hasProfit ? day.profitPercent! / 100 : "",
      "0.00%",
    );
    putFormula(
      sheet,
      `I${row}`,
      `=IF(D${row}="","",IF(H${row}>=$C$5,"✔","✘"))`,
      day.targetMet === null ? "" : day.targetMet ? "✔" : "✘",
    );
    putFormula(
      sheet,
      `L${row}`,
      `=K${row}*$C$4`,
      day.targetBalanceIDR,
      '"Rp" #,##0.00',
    );
  }

  putFormula(sheet, "H3", "=SUM(D13:D142)", summary.totalProfitUSC, "#,##0.00");
  putFormula(sheet, "H4", "=SUM(E13:E142)", summary.totalProfitIDR, '"Rp" #,##0.00');
  putFormula(sheet, "H5", "=C3+SUM(D13:D142)", summary.actualBalanceUSC, "#,##0.00");
  putFormula(sheet, "H6", "=H5*C4", summary.actualBalanceIDR, '"Rp" #,##0.00');
  putFormula(
    sheet,
    "H7",
    '=COUNTIF(I13:I142,"✔")&" dari "&COUNT(D13:D142)&" hari terisi"',
    `${summary.daysMet} dari ${summary.daysFilled} hari terisi`,
  );
  putFormula(
    sheet,
    "H8",
    '=IF(COUNT(D13:D142)=0,0,H5-INDEX(K13:K142,COUNT(D13:D142)))',
    summary.positionVsTargetUSC,
    "#,##0.00",
  );

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, sheet, SHEET_NAME);
  const output = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
  return new Blob([output], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
}
