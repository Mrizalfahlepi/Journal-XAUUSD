import { type FormEvent, type ReactNode, useEffect, useMemo, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import {
  getGetCurrentUserQueryKey,
  getGetJournalQueryKey,
  useChangeAccountName,
  useChangeAccountPin,
  useGetCurrentUser,
  useGetJournal,
  useImportBrowserJournal,
  useLogin,
  useLogout,
} from '@workspace/api-client-react';
import type { JournalDocument as ApiJournalDocument } from '@workspace/api-client-react';
import { useJournal, type JournalDocumentState } from '@/hooks/use-journal';
import { calculateJournal, createDefaultJournal, type CalculatedDay, type JournalParameters } from '@/domain/journal';
import { exportJournal, importJournal } from '@/lib/excel';
import { formatDate, formatIDR, formatNumber, formatPercent, formatUSC } from '@/lib/format';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { retry: 1, refetchOnWindowFocus: true },
    mutations: { retry: 0 },
  },
});

type View = 'overview' | 'journal' | 'analytics' | 'settings';
type IconName = 'overview' | 'journal' | 'analytics' | 'settings' | 'download' | 'upload' | 'calendar' | 'target' | 'logout' | 'lock' | 'person' | 'sun' | 'moon' | 'device' | 'award' | 'arrow' | 'retry' | 'secure' | 'trend' | 'check' | 'save';

function Icon({ name, className = '' }: { name: IconName; className?: string }) {
  const base = { fill: 'none', stroke: 'currentColor', strokeWidth: 1.5, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const };
  const children: Record<IconName, ReactNode> = {
    overview: <><rect {...base} x="2.5" y="2.5" width="6.1" height="6.1" rx="1.4" /><rect {...base} x="11.4" y="2.5" width="6.1" height="4" rx="1.2" /><rect {...base} x="11.4" y="8.8" width="6.1" height="8.7" rx="1.4" /><rect {...base} x="2.5" y="11" width="6.1" height="6.5" rx="1.4" /></>,
    journal: <><path {...base} d="M5 2.8h7.2l3.1 3v11.4H5z" /><path {...base} d="M12.2 2.8v3.1h3.1M7.3 9h5.8M7.3 11.8h5.8M7.3 14.6h3.4" /></>,
    analytics: <><path {...base} d="M2.5 16.8h15" /><path {...base} d="M4 14v-3M8 14V6M12 14V9M16 14V3.5" /><path {...base} d="m3.5 8 3-2.6 3.2 2.1 5.8-4" /></>,
    settings: <><circle {...base} cx="10" cy="10" r="3" /><path {...base} d="M10 2.4v1.4M10 16.2v1.4M17.6 10h-1.4M3.8 10H2.4m13-5.2-1 1M5.6 14.4l-1 1m10.8 0-1-1m-8.8-8.8-1-1" /><circle {...base} cx="10" cy="10" r="7.5" /></>,
    download: <><path {...base} d="M10 2.7v9.1m-3.6-3.5 3.6 3.7 3.6-3.7M3.1 13.5v3.6h13.8v-3.6" /></>,
    upload: <><path {...base} d="M10 12.2V3.1m-3.6 3.6L10 3l3.6 3.7M3.1 13.5v3.6h13.8v-3.6" /></>,
    calendar: <><rect {...base} x="2.7" y="4.1" width="14.6" height="12.5" rx="2" /><path {...base} d="M6.3 2.5v3.2m7.4-3.2v3.2M2.9 8h14.2m-10 3h.1m3 0h.1m3 0h.1m-6.2 3h.1m3 0h.1" /></>,
    target: <><circle {...base} cx="9" cy="11" r="6.6" /><circle {...base} cx="9" cy="11" r="3" /><path {...base} d="m9 11 6.4-6.4m-2.8 0h2.8v2.8" /></>,
    logout: <><path {...base} d="M8 3.1H4.2v13.8H8m4-10 4.1 3.1-4.1 3.1m3.9-3.1H7.2" /></>,
    lock: <><rect {...base} x="3.1" y="8" width="13.8" height="9" rx="1.8" /><path {...base} d="M6.1 8V5.8a3.9 3.9 0 0 1 7.8 0V8M10 11.3v2.4" /></>,
    person: <><circle {...base} cx="10" cy="6.2" r="3.1" /><path {...base} d="M3.2 17c.7-3.1 3.2-4.8 6.8-4.8s6.1 1.7 6.8 4.8" /></>,
    sun: <><circle {...base} cx="10" cy="10" r="3.4" /><path {...base} d="M10 1.8v2m0 12.4v2M1.8 10h2m12.4 0h2M4.2 4.2l1.4 1.4m8.8 8.8 1.4 1.4m0-11.6-1.4 1.4m-8.8 8.8-1.4 1.4" /></>,
    moon: <><path {...base} d="M15.7 12.9A7.2 7.2 0 0 1 7.1 4.3a7.4 7.4 0 1 0 8.6 8.6Z" /><path {...base} d="M12.5 3.1v2.2m-1.1-1.1h2.2" /></>,
    device: <><rect {...base} x="5.1" y="2.1" width="9.8" height="15.8" rx="2" /><path {...base} d="M8.4 4.8h3.2m-1.6 10.3h.1" /></>,
    award: <><path {...base} d="m6.3 11.7-1 5.7 4.7-2.5 4.7 2.5-1-5.7" /><circle {...base} cx="10" cy="7.3" r="5.1" /><path {...base} d="m8 7.4 1.3 1.3 2.8-3" /></>,
    arrow: <><path {...base} d="M3 10h13m-5-5 5 5-5 5" /></>,
    retry: <><path {...base} d="M15.8 7.1A6.4 6.4 0 0 0 5 5.4L3.8 6.8M3.8 3.5v3.6h3.6M4.2 12.9A6.4 6.4 0 0 0 15 14.6l1.2-1.4m0 3.3v-3.6h-3.6" /></>,
    secure: <><path {...base} d="m10 2.2 6.4 2.5v4.9c0 3.8-2.6 6.8-6.4 8.2-3.8-1.4-6.4-4.4-6.4-8.2V4.7L10 2.2Z" /><path {...base} d="m7.2 9.7 1.9 1.9 3.8-4" /></>,
    trend: <><path {...base} d="m2.7 14 4-4.2 3 2.5 6.8-7.1m-4.1 0h4.1v4.1" /></>,
    check: <><circle {...base} cx="10" cy="10" r="7.2" /><path {...base} d="m6.6 10 2.3 2.3 4.7-4.7" /></>,
    save: <><path {...base} d="M3 3h11.4L17 5.6V17H3z" /><path {...base} d="M6 3v4h7V3m-7 14v-6h8v6" /></>,
  };
  return <svg viewBox="0 0 20 20" className={`icon ${className}`} aria-hidden="true">{children[name]}</svg>;
}

const navItems: { id: View; label: string; icon: IconName }[] = [
  { id: 'overview', label: 'Dashboard', icon: 'overview' },
  { id: 'journal', label: 'Jurnal', icon: 'journal' },
  { id: 'analytics', label: 'Analitik', icon: 'analytics' },
  { id: 'settings', label: 'Pengaturan', icon: 'settings' },
];
const LEGACY_KEY = 'trading-journal.local.v1';

type LegacyJournal = { parameters: JournalParameters; entries: { profitUSC: number | null; note: string }[]; appearanceMode: 'system' | 'light' | 'dark' };

function dateLabel(value: string) {
  try { return formatDate(value); } catch { return value; }
}
function moneyUSC(value: number | null | undefined) { return formatUSC(value); }
function moneyIDR(value: number | null | undefined) { return formatIDR(value); }
function percent(value: number) { return formatPercent(value); }

function legacyJournal(): LegacyJournal | null {
  try {
    const raw = window.localStorage.getItem(LEGACY_KEY);
    if (!raw) return null;
    const decoded = JSON.parse(raw) as Partial<LegacyJournal>;
    if (!decoded.parameters || !Array.isArray(decoded.entries)) return null;
    const defaults = createDefaultJournal();
    const p = decoded.parameters;
    const parameters: JournalParameters = {
      initialBalanceUSC: typeof p.initialBalanceUSC === 'number' ? p.initialBalanceUSC : defaults.parameters.initialBalanceUSC,
      exchangeRateIDR: typeof p.exchangeRateIDR === 'number' ? p.exchangeRateIDR : defaults.parameters.exchangeRateIDR,
      targetRate: typeof p.targetRate === 'number' ? p.targetRate : defaults.parameters.targetRate,
      startDate: typeof p.startDate === 'string' ? p.startDate.slice(0, 10) : defaults.parameters.startDate,
    };
    const entries = Array.from({ length: 130 }, (_, i) => ({
      profitUSC: typeof decoded.entries?.[i]?.profitUSC === 'number' ? decoded.entries[i].profitUSC : null,
      note: typeof decoded.entries?.[i]?.note === 'string' ? decoded.entries[i].note : '',
    }));
    const meaningful = entries.some((entry) => entry.profitUSC !== null || entry.note.trim() !== '');
    if (!meaningful) return null;
    const appearanceMode = decoded.appearanceMode === 'dark' || decoded.appearanceMode === 'light' ? decoded.appearanceMode : 'system';
    return { parameters, entries, appearanceMode };
  } catch {
    return null;
  }
}

function apiDocument(document: LegacyJournal | JournalDocumentState): ApiJournalDocument {
  return {
    parameters: { ...document.parameters, startDate: new Date(`${document.parameters.startDate}T00:00:00.000Z`) },
    entries: document.entries,
    appearanceMode: document.appearanceMode,
  } as ApiJournalDocument;
}

function errorMessage(error: unknown, fallback: string) {
  return error instanceof Error ? error.message : fallback;
}

function LoginScreen({ onSuccess }: { onSuccess: () => void }) {
  const client = useQueryClient();
  const loginMutation = useLogin();
  const [name, setName] = useState('');
  const [pin, setPin] = useState('');
  const [showPin, setShowPin] = useState(false);
  const [formError, setFormError] = useState('');
  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setFormError('');
    if (!name.trim()) { setFormError('Masukkan nama akun Anda.'); return; }
    if (!/^\d{4,6}$/.test(pin)) { setFormError('PIN harus terdiri dari 4 sampai 6 angka.'); return; }
    loginMutation.mutate({ data: { name: name.trim(), pin } }, {
      onSuccess: (result) => {
        client.setQueryData(getGetCurrentUserQueryKey(), result);
        client.removeQueries({ queryKey: getGetJournalQueryKey() });
        onSuccess();
      },
      onError: (error) => setFormError(errorMessage(error, 'Tidak dapat masuk. Periksa nama akun dan PIN.')),
    });
  };
  return <main className="auth-scene">
    <div className="auth-atmosphere" aria-hidden="true"><span /><span /><span /></div>
    <section className="auth-frame">
      <div className="auth-brand"><span className="brand-mark" /><div><strong>XAUUSD</strong><small>Trading journal</small></div></div>
      <div className="auth-copy"><div className="eyebrow">Personal trading workspace</div><h1>Jaga proses.<br /><em>Ukur pertumbuhan.</em></h1><p>Ruang privat untuk mencatat hasil harian, menjaga ritme, dan meninjau perjalanan menuju target Anda.</p></div>
      <form className="auth-card" onSubmit={submit}>
        <div className="auth-card-heading"><span className="auth-seal"><Icon name="secure" /></span><div><h2>Masuk ke jurnal</h2><p>Akun Anda hanya tersedia untuk Anda.</p></div></div>
        <div className="field"><label htmlFor="login-name">Nama akun</label><div className="input-wrap"><Icon name="person" /><input id="login-name" autoComplete="username" maxLength={60} value={name} onChange={(event) => setName(event.target.value)} placeholder="Nama yang Anda gunakan" data-testid="input-login-name" /></div></div>
        <div className="field"><label htmlFor="login-pin">PIN pribadi</label><div className="input-wrap"><Icon name="lock" /><input id="login-pin" type={showPin ? 'text' : 'password'} inputMode="numeric" autoComplete="current-password" pattern="[0-9]{4,6}" minLength={4} maxLength={6} value={pin} onChange={(event) => setPin(event.target.value.replace(/\D/g, '').slice(0, 6))} placeholder="4–6 angka" data-testid="input-login-pin" /><button className="field-suffix" type="button" onClick={() => setShowPin((current) => !current)} aria-label={showPin ? 'Sembunyikan PIN' : 'Tampilkan PIN'} data-testid="button-toggle-pin">{showPin ? 'Sembunyikan' : 'Tampilkan'}</button></div></div>
        {formError && <div className="form-alert" role="alert" data-testid="login-error">{formError}</div>}
        <button className="button primary auth-submit" type="submit" disabled={loginMutation.isPending} data-testid="button-login">{loginMutation.isPending ? <span className="button-loader" /> : <>Masuk dengan aman <Icon name="arrow" /></>}</button>
        <p className="auth-first-note">Belum pernah masuk? Nama akun dan PIN akan membentuk ruang jurnal pertama Anda.</p>
      </form>
      <div className="auth-privacy"><Icon name="lock" /> Enkripsi sesi · tidak ada profil publik · data Anda tetap milik Anda</div>
    </section>
    <aside className="auth-side-note"><div className="side-orbit"><span /><span /><span /><b /></div><p>Compound growth<br />is a practice.</p><small>One considered day at a time.</small></aside>
  </main>;
}

function LoadingPanel({ label = 'Memuat jurnal Anda' }: { label?: string }) {
  return <div className="loading-scene" role="status" aria-live="polite"><div className="skeleton-mark" /><p>{label}</p><div className="loading-lines"><i /><i /><i /></div></div>;
}

function TransferPrompt({ source, onTransfer, onDecline, busy, error }: {
  source: LegacyJournal; onTransfer: () => void; onDecline: () => void; busy: boolean; error: string;
}) {
  const count = source.entries.filter((entry) => entry.profitUSC !== null || entry.note.trim()).length;
  return <div className="transfer-backdrop">
    <section className="transfer-dialog glass" role="dialog" aria-modal="true" aria-labelledby="transfer-title" data-testid="dialog-browser-transfer">
      <div className="transfer-seal"><Icon name="download" /></div>
      <div className="eyebrow">Browser journal detected</div><h1 id="transfer-title">Bawa catatan lama Anda?</h1>
      <p>Jurnal yang tersimpan di browser ini memiliki <strong>{count} hari berisi data</strong>. Pindahkan ke akun Rizal untuk melanjutkan dari sini.</p>
      <div className="transfer-preview"><span>Modal awal <strong>{moneyUSC(source.parameters.initialBalanceUSC)}</strong></span><span>Catatan mulai <strong>{dateLabel(source.parameters.startDate)}</strong></span></div>
      {error && <div className="form-alert" role="alert">{error}</div>}
      <div className="transfer-actions"><button type="button" className="button primary" onClick={onTransfer} disabled={busy} data-testid="button-transfer-legacy">{busy ? <span className="button-loader" /> : <>Pindahkan catatan <Icon name="arrow" /></>}</button><button type="button" className="button" onClick={onDecline} disabled={busy} data-testid="button-decline-transfer">Nanti saja</button></div>
      <small>Data browser lama tidak akan dihapus sampai transfer berhasil dikonfirmasi.</small>
    </section>
  </div>;
}

function BalanceChart({ days, parameters }: { days: CalculatedDay[]; parameters: JournalParameters }) {
  const points = useMemo(() => days.filter((day) => day.profitUSC !== null), [days]);
  const visible = points.length ? points : [days[0]].filter(Boolean);
  const w = 700, h = 230, l = 54, r = 15, t = 15, b = 34;
  const current = visible.map((item) => item.actualBalanceUSC ?? parameters.initialBalanceUSC);
  const planned = visible.map((item) => item.targetBalanceUSC);
  const all = [...current, ...planned, parameters.initialBalanceUSC];
  const low = Math.min(...all) * .965;
  const high = Math.max(...all) * 1.03 || 1;
  const px = (index: number) => l + index * (w - l - r) / Math.max(visible.length - 1, 1);
  const py = (value: number) => t + (high - value) * (h - t - b) / Math.max(1, high - low);
  const line = (values: number[]) => values.map((v, i) => `${i ? 'L' : 'M'}${px(i)},${py(v)}`).join(' ');
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);
  const active = hoverIndex === null ? null : visible[hoverIndex];
  const lineActual = line(current);
  const lineTarget = line(planned);
  const labelIndices = [...new Set([0, Math.floor((visible.length - 1) / 2), visible.length - 1])];
  return <div className="chart-wrap balance-chart" data-testid="chart-actual-target">
    <svg className="chart-svg" viewBox={`0 0 ${w} ${h}`} role="img" aria-label="Saldo aktual dibandingkan target majemuk">
      <defs><linearGradient id="balance-area" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="#287e74" stopOpacity=".22" /><stop offset="1" stopColor="#287e74" stopOpacity="0" /></linearGradient></defs>
      {[0,.33,.66,1].map((step) => {
        const value = low + (high-low) * step;
        return <g key={step}><line className="chart-grid" x1={l} x2={w-r} y1={py(value)} y2={py(value)} /><text className="chart-label" x={l-8} y={py(value)+3} textAnchor="end">{formatNumber(value/1000, 1)}k</text></g>;
      })}
      {visible.length > 1 && <path d={`${lineActual} L${px(visible.length-1)},${h-b} L${px(0)},${h-b} Z`} fill="url(#balance-area)" />}
      <path d={lineTarget} fill="none" stroke="var(--gold-ink)" strokeOpacity=".85" strokeWidth="1.8" strokeDasharray="5 5" />
      <path d={lineActual} fill="none" stroke="var(--teal-ink)" strokeWidth="2.7" strokeLinecap="round" strokeLinejoin="round" />
      {visible.map((day,index) => <circle key={day.number} cx={px(index)} cy={py(current[index])} r={hoverIndex===index?5:3.2} fill="var(--teal-ink)" stroke="var(--surface)" strokeWidth="2" tabIndex={0} role="img" aria-label={`${day.date}: actual ${moneyUSC(current[index])}, target ${moneyUSC(planned[index])}`} onMouseEnter={() => setHoverIndex(index)} onMouseLeave={() => setHoverIndex(null)} onFocus={() => setHoverIndex(index)} onBlur={() => setHoverIndex(null)}><title>{`${dateLabel(day.date)} · aktual ${moneyUSC(current[index])} · target ${moneyUSC(planned[index])}`}</title></circle>)}
      {labelIndices.map((index) => <text key={index} className="chart-label" x={px(index)} y={h-9} textAnchor={index===0?'start':index===visible.length-1?'end':'middle'}>{dateLabel(visible[index].date)}</text>)}
    </svg>
    {active && <div className="chart-tooltip" style={{left:`clamp(76px, ${px(hoverIndex!) / w * 100}%, calc(100% - 76px))`}} role="status" data-testid="chart-tooltip"><strong>{dateLabel(active.date)} · Day {active.number}</strong><span>Aktual <b>{moneyUSC(active.actualBalanceUSC)}</b></span><span>Target <b>{moneyUSC(active.targetBalanceUSC)}</b></span><span>Profit <b>{moneyUSC(active.profitUSC)}</b></span></div>}
  </div>;
}

function DailyProfitChart({ days }: { days: CalculatedDay[] }) {
  const rows = days.filter((day) => day.profitUSC !== null).slice(0, 35);
  if (!rows.length) return <div className="empty-state">Belum ada hasil untuk divisualisasikan.</div>;
  const w=700,h=170, mid=82, margin=12, slot=(w-margin*2)/rows.length;
  const max=Math.max(1,...rows.map((day)=>Math.abs(day.profitUSC ?? 0)));
  return <div className="chart-wrap profit-chart" data-testid="chart-daily-profit"><svg className="chart-svg" viewBox={`0 0 ${w} ${h}`} role="img" aria-label="Profit harian pada hari-hari yang sudah dicatat">
    <line className="chart-grid" x1={margin} x2={w-margin} y1={mid} y2={mid} />
    {rows.map((day,index)=>{ const value=day.profitUSC ?? 0; const bar=Math.max(2,Math.abs(value)/max*59); const x=margin+index*slot+slot*.21; return <g key={day.number}><rect x={x} y={value>=0?mid-bar:mid} width={Math.max(3,slot*.56)} height={bar} rx="3" fill={value>0?'var(--teal-ink)':value<0?'var(--coral-ink)':'var(--line-strong)'} opacity=".88"><title>{`${dateLabel(day.date)} · ${moneyUSC(value)}`}</title></rect><rect x={margin+index*slot} y="8" width={slot} height="150" fill="transparent" tabIndex={0} aria-label={`${dateLabel(day.date)}: profit ${moneyUSC(value)}`}><title>{`${dateLabel(day.date)} · ${moneyUSC(value)}`}</title></rect></g>;})}
    <text className="chart-label" x={margin} y={h-7}>{dateLabel(rows[0].date)}</text><text className="chart-label" x={w-margin} y={h-7} textAnchor="end">{dateLabel(rows[rows.length-1].date)}</text>
  </svg></div>;
}

function Heatmap({ days }: { days: CalculatedDay[] }) {
  const monthLabels = new Map<string, number>();
  const first = days[0]?.date;
  const start = first ? new Date(`${first}T00:00:00Z`).getTime() : 0;
  const dayMap = new Map(days.map((day) => [day.date, day]));
  const weeks: (CalculatedDay | null)[][] = [];
  let week: (CalculatedDay | null)[] = [];
  days.forEach((day) => {
    const weekday = new Date(`${day.date}T00:00:00Z`).getUTCDay();
    if (!week.length) week = Array(5).fill(null);
    const row = weekday === 0 ? 4 : weekday - 1;
    week[row] = day;
    if (row === 4 || day.number === days.length) {
      weeks.push(week);
      week = [];
    }
  });
  days.forEach((day) => {
    const month = day.date.slice(0,7);
    if (!monthLabels.has(month)) monthLabels.set(month, day.number);
  });
  const years = days.map((day) => day.date.slice(0,4));
  const heat = (day: CalculatedDay | null) => {
    if (!day || day.profitUSC === null) return 'heat-empty';
    if (day.profitUSC < 0) return 'heat-loss';
    if (day.targetMet) return 'heat-achievement';
    return 'heat-profit';
  };
  return <div className="heatmap-shell" data-testid="chart-daily-heatmap">
    <div className="heatmap-months" style={{gridTemplateColumns:`repeat(${weeks.length}, minmax(8px, 1fr))`}}>
      {weeks.map((_, index) => {
        const startOfWeek = days.find((day) => Math.floor((Date.parse(`${day.date}T00:00:00Z`) - start) / (7 * 86400000)) === index);
        const month = startOfWeek?.date.slice(0,7);
        return <span key={index}>{month && monthLabels.get(month) === startOfWeek?.number ? new Intl.DateTimeFormat('id-ID',{month:'short',timeZone:'UTC'}).format(new Date(`${month}-01T00:00:00Z`)) : ''}</span>;
      })}
    </div>
    <div className="heatmap-grid-wrap">
      <div className="heatmap-weekdays"><span>S</span><span>S</span><span>R</span><span>K</span><span>J</span></div>
      <div className="heatmap-grid" style={{gridTemplateColumns:`repeat(${weeks.length}, minmax(8px, 1fr))`}}>
        {weeks.map((group, column) => <div className="heatmap-week" key={column}>{group.map((day, row) => day ? <div key={row} className={`heat-cell ${heat(day)} ${day.milestone?'heat-milestone':''}`} tabIndex={0} title={`${dateLabel(day.date)} · ${day.profitUSC === null ? 'Belum dicatat' : moneyUSC(day.profitUSC)}${day.targetMet ? ' · Target tercapai' : ''}`} aria-label={`${dateLabel(day.date)} ${day.profitUSC === null ? 'belum dicatat' : `profit ${moneyUSC(day.profitUSC)}`}${day.targetMet ? ', target tercapai' : ''}`} data-testid={`heat-day-${day.number}`} /> : <span key={row} className="heat-cell heat-blank" />)}</div>)}
      </div>
    </div>
    <div className="heatmap-legend"><span><i className="heat-empty" /> Belum</span><span><i className="heat-loss" /> Rugi</span><span><i className="heat-profit" /> Profit</span><span><i className="heat-achievement" /> Target</span></div>
  </div>;
}

function streakMetrics(days: CalculatedDay[]) {
  let best = 0;
  let run = 0;
  for (const day of days) {
    if (day.profitUSC === null) { run = 0; continue; }
    if (day.targetMet) { run += 1; best = Math.max(best, run); } else run = 0;
  }
  let current = 0;
  for (let i = days.length - 1; i >= 0; i -= 1) {
    const day = days[i];
    if (day.profitUSC === null) continue;
    if (!day.targetMet) break;
    current += 1;
  }
  return { current, best };
}

function useTheme(mode: 'system' | 'light' | 'dark') {
  useEffect(() => {
    const media = window.matchMedia('(prefers-color-scheme: dark)');
    const apply = () => {
      const theme = mode === 'system' ? (media.matches ? 'dark' : 'light') : mode;
      document.documentElement.dataset.theme = theme;
      document.documentElement.style.colorScheme = theme;
    };
    apply();
    media.addEventListener('change', apply);
    return () => media.removeEventListener('change', apply);
  }, [mode]);
}

function AppContent({ user, onLogout }: { user: { id: string; name: string }; onLogout: () => void }) {
  const client = useQueryClient();
  const journal = useJournal();
  const importMutation = useImportBrowserJournal();
  const [view, setView] = useState<View>('overview');
  const [period, setPeriod] = useState('all');
  const [notice, setNotice] = useState('');
  const [importError, setImportError] = useState('');
  const uploadRef = useRef<HTMLInputElement>(null);
  const legacy = useMemo(() => legacyJournal(), []);
  useTheme(journal.appearanceMode);
  const { parameters, entries, days, summary } = journal;
  const filled = useMemo(() => days.filter((day) => day.profitUSC !== null), [days]);
  const recent = [...filled].reverse().slice(0,4);
  const currentBalance = summary.actualBalanceUSC;
  const currentIDR = summary.actualBalanceIDR;
  const progress = Math.max(0, Math.min(100, summary.actualProgressPercent));
  const streak = useMemo(() => streakMetrics(days), [days]);
  const latestDay = summary.lastFilled;
  const nextDay = summary.nextEntry;
  const shownDays = period === 'filled' ? days.filter((day) => day.profitUSC !== null) : period === 'open' ? days.filter((day) => day.profitUSC === null) : days;

  const notify = (text: string) => {
    setNotice(text);
    window.setTimeout(() => setNotice(''), 4000);
  };
  const doExport = async () => {
    try {
      const blob = await exportJournal(parameters, entries);
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.download = 'Jurnal-XAUUSD-USC.xlsx';
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 1200);
      notify('Workbook berhasil diekspor.');
    } catch (error) { notify(errorMessage(error, 'Workbook tidak dapat diekspor.')); }
  };
  const doExcelImport = async (file?: File) => {
    if (!file) return;
    try {
      const imported = await importJournal(file);
      if (!window.confirm('Workbook ini akan mengganti parameter, profit, dan catatan jurnal. Lanjutkan?')) return;
      journal.replaceJournal({ ...imported, appearanceMode: journal.appearanceMode });
      notify('Jurnal dari workbook berhasil dimuat dan sedang disimpan.');
    } catch (error) { setImportError(errorMessage(error, 'File tidak dapat dibaca.')); }
    finally { if (uploadRef.current) uploadRef.current.value = ''; }
  };
  const transferLegacy = async () => {
    if (!legacy) return;
    setImportError('');
    try {
      const result = await importMutation.mutateAsync({ data: { journal: apiDocument(legacy) } });
      window.localStorage.removeItem(LEGACY_KEY);
      journal.replaceJournal({
        parameters: { ...result.journal.parameters, startDate: new Date(result.journal.parameters.startDate).toISOString().slice(0,10) },
        entries: result.journal.entries,
        appearanceMode: result.journal.appearanceMode,
      });
      client.setQueryData(getGetJournalQueryKey(), { journal: result.journal, hasExistingRemoteData: true });
      notify(`Transfer selesai. ${result.importedEntries} entri dimuat.`);
    } catch (error) { setImportError(errorMessage(error, 'Transfer belum berhasil. Data browser Anda tetap aman.')); }
  };
  const pageTitle: Record<View,string> = { overview:'Dashboard', journal:'Jurnal', analytics:'Analitik', settings:'Pengaturan' };
  const saveLabel = journal.saveStatus === 'loading' ? 'Memuat data' : journal.saveStatus === 'saving' ? 'Menyimpan' : journal.saveStatus === 'error' ? 'Gagal menyimpan' : journal.saveStatus === 'unsaved' ? 'Menunggu simpan' : 'Tersimpan';

  if (journal.loading) return <LoadingPanel />;
  if (journal.error) return <section className="workspace-error glass"><Icon name="secure" /><h1>Jurnal belum dapat dimuat</h1><p>Sesi Anda masih aktif, tetapi data akun belum tersedia. Periksa koneksi lalu coba lagi.</p><button className="button primary" onClick={() => void journal.refetch()} data-testid="button-retry-journal"><Icon name="retry" /> Coba lagi</button></section>;

  return <div className="app-shell" data-testid="authenticated-workspace">
    <aside className="sidebar" aria-label="Navigasi utama">
      <div className="brand"><span className="brand-mark" aria-hidden="true" /><span><span className="brand-name">XAUUSD</span><span className="brand-sub">Trading journal</span></span></div>
      <div className="nav-caption">Workspace</div>
      <nav className="nav-list">{navItems.map((item) => <button key={item.id} type="button" className={`nav-item ${view===item.id?'active':''}`} onClick={() => setView(item.id)} data-testid={`nav-${item.id}`} aria-current={view===item.id?'page':undefined}><Icon name={item.icon} />{item.label}</button>)}</nav>
      <div className="sidebar-account"><div className="account-avatar">{user.name.trim().slice(0,1).toUpperCase()}</div><span><strong>{user.name}</strong><small>Private workspace</small></span></div>
      <div className="sidebar-foot"><div className={`save-indicator save-${journal.saveStatus}`}><i />{saveLabel}</div><small>Data tersimpan ke akun Anda</small></div>
    </aside>
    <main className="main">
      <header className="topbar">
        <div className="crumb">XAUUSD <span aria-hidden="true">/</span> <strong>{pageTitle[view]}</strong><span className="mobile-account">{user.name}</span></div>
        <div className="top-actions">
          <div className={`save-indicator top-save save-${journal.saveStatus}`} role="status" aria-live="polite" data-testid="status-save"><i />{saveLabel}</div>
          <input className="file-hidden" ref={uploadRef} type="file" accept=".xlsx,.xls" aria-label="Pilih workbook Excel" data-testid="input-import-file" onChange={(event) => void doExcelImport(event.target.files?.[0])} />
          <button type="button" className="button" onClick={() => uploadRef.current?.click()} data-testid="button-import"><Icon name="upload" /><span className="button-text">Impor Excel</span></button>
          <button type="button" className="button primary" onClick={() => void doExport()} data-testid="button-export"><Icon name="download" /><span className="button-text">Ekspor</span></button>
        </div>
      </header>
      {notice && <div className="inline-notice" role="status" data-testid="status-notice">{notice}</div>}
      {journal.saveError && <div className="inline-notice is-error" role="alert" data-testid="status-save-error">{journal.saveError}<button type="button" onClick={() => journal.refetch()} data-testid="button-reload-after-save">Muat ulang</button></div>}
      {legacy && <div className="migration-nudge"><span className="migration-nudge-mark"><Icon name="download" /></span><span><strong>Catatan browser lama tersedia.</strong> Transfer kapan saja dari Pengaturan, tanpa menghapus sebelum berhasil.</span><button className="text-action" type="button" onClick={() => setView('settings')} data-testid="button-open-transfer-settings">Tinjau <Icon name="arrow" /></button></div>}
      <div className="page-enter" key={view}>
        {view==='overview' && <section>
          <div className="page-heading"><div><div className="eyebrow">Personal trading record · {new Date(`${parameters.startDate}T00:00:00Z`).getUTCFullYear()}</div><h1>Ruang kendali, {user.name.split(' ')[0]}.</h1><p className="page-subtitle">Performa nyata, dibandingkan dengan rencana yang Anda tetapkan.</p></div><div className="date-stamp"><Icon name="calendar" /> {latestDay ? `Terakhir dicatat · ${dateLabel(latestDay.date)}` : `Mulai · ${dateLabel(parameters.startDate)}`}<br /><span>{nextDay ? `Berikutnya · Hari ${nextDay.number}` : 'Semua hari telah berlalu'}</span></div></div>
          <div className="overview-grid">
            <article className="glass metric-card primary-metric" data-testid="metric-current-balance"><div className="metric-label">Saldo aktual · USC</div><div className="metric-value mono">{moneyUSC(currentBalance)}</div><div className="metric-foot">{moneyIDR(currentIDR)} · modal awal {moneyUSC(parameters.initialBalanceUSC)}</div></article>
            <article className="glass metric-card" data-testid="metric-total-profit"><div className="metric-label">Profit terealisasi</div><div className={`metric-value mono ${summary.totalProfitUSC>=0?'positive':'negative'}`}>{summary.totalProfitUSC>=0?'+':''}{moneyUSC(summary.totalProfitUSC)}</div><div className="metric-foot">{moneyIDR(summary.totalProfitIDR)} dari {summary.daysFilled} hari tercatat</div></article>
            <article className="glass metric-card" data-testid="metric-total-return"><div className="metric-label">Return pada modal</div><div className={`metric-value mono ${summary.totalProfitPercent>=0?'positive':'negative'}`}>{percent(summary.totalProfitPercent)}</div><div className="metric-foot">aktual sejak hari pertama</div></article>
            <article className="glass metric-card" data-testid="metric-daily-target"><div className="metric-label">Target berikutnya</div><div className="metric-value mono">{moneyUSC(summary.currentTargetProfitUSC)}</div><div className="metric-foot">Hari {nextDay.number} · {dateLabel(nextDay.date)}</div></article>
          </div>
          <div className="stats-strip dashboard-stats">
            <article className="glass small-stat"><span>Hasil tercatat</span><strong>{summary.daysFilled} <small className="muted">/ 130</small></strong></article>
            <article className="glass small-stat"><span>Hari target tercapai</span><strong>{summary.daysMet} <small className="muted">/ {summary.daysFilled}</small></strong></article>
            <article className="glass small-stat"><span>Gap ke target berikutnya</span><strong className={summary.targetGapUSC>0?'negative':'positive'}>{summary.targetGapUSC>0?'−':'+'}{moneyUSC(Math.abs(summary.targetGapUSC))}</strong></article>
            <article className="glass small-stat"><span>Posisi vs jalur target</span><strong className={summary.positionVsTargetUSC>=0?'positive':'negative'}>{summary.positionVsTargetUSC>=0?'+':'−'}{moneyUSC(Math.abs(summary.positionVsTargetUSC))}</strong></article>
          </div>
          <div className="content-grid">
            <article className="glass panel"><div className="panel-head"><div><h2 className="panel-title">Saldo aktual dan rencana</h2><div className="panel-note">Nilai USC pada hari yang sudah dicatat · fokus titik untuk rincian</div></div><div className="legend"><span><i /> Aktual</span><span className="target"><i /> Target</span></div></div><BalanceChart days={days} parameters={parameters} /></article>
            <article className="glass panel goal-panel" data-testid="card-milestone"><div><div className="panel-head"><div><h2 className="panel-title">Milestone Rp100 juta</h2><div className="panel-note">Progress berdasarkan saldo aktual</div></div><Icon name="target" /></div><div className="goal-figure"><div className="goal-ring"><svg viewBox="0 0 100 100" aria-hidden="true"><circle className="track" cx="50" cy="50" r="42" /><circle className="progress" cx="50" cy="50" r="42" strokeDasharray={`${2*Math.PI*42}`} strokeDashoffset={`${2*Math.PI*42*(1-progress/100)}`} /></svg><div className="ring-center"><strong>{percent(progress)}</strong><span>tercapai</span></div></div></div></div><div className="milestone-copy"><strong>{summary.targetMilestone?`Proyeksi · Hari ${summary.targetMilestone.number}`:'Masih dalam jangkauan'}</strong><p>{summary.targetMilestone?`${dateLabel(summary.targetMilestone.date)} · target saldo ${moneyIDR(summary.targetMilestone.targetBalanceIDR)}.`:`Saldo aktual ${moneyIDR(currentIDR)} dari Rp100 juta.`}</p></div></article>
          </div>
          <article className="glass panel recent-panel"><div className="panel-head"><div><h2 className="panel-title">Aktivitas terakhir</h2><div className="panel-note">Catatan dari perjalanan trading Anda</div></div><button className="button" type="button" onClick={()=>setView('journal')} data-testid="button-view-journal">Buka jurnal <Icon name="arrow" /></button></div>{recent.length?<div className="recent-list">{recent.map((day)=><div className="recent-row" key={day.number} data-testid={`row-recent-${day.number}`}><span className="recent-day">{dateLabel(day.date)} <span className="muted">· Hari {day.number}</span></span><span className={`mono ${(day.profitUSC??0)>=0?'positive':'negative'}`}>{(day.profitUSC??0)>=0?'+':''}{moneyUSC(day.profitUSC)}</span><span className="recent-idr mono muted">{moneyIDR(day.profitIDR)}</span><span className={`status-pill ${day.targetMet?'':'pending'}`}>{day.targetMet?'Target terpenuhi':'Di bawah target'}</span></div>)}</div>:<div className="empty-state">Belum ada hasil trading untuk ditampilkan.</div>}</article>
        </section>}

        {view==='journal' && <section>
          <div className="page-heading"><div><div className="eyebrow">Daily log · XAUUSD / USC</div><h1>Jurnal trading</h1><p className="page-subtitle">130 hari kerja untuk mencatat profit bersih dan konteks di balik angka.</p></div><div className="date-stamp">{summary.daysFilled} dari 130 hari tercatat</div></div>
          <article className="glass panel journal-panel"><div className="filters-row"><div><h2 className="panel-title">Checklist harian</h2><div className="panel-note">Profit kosong berarti belum dicatat. Catatan disimpan otomatis.</div></div><select className="filter-select" aria-label="Filter hari jurnal" value={period} onChange={(event)=>setPeriod(event.target.value)} data-testid="select-journal-filter"><option value="all">Semua hari</option><option value="filled">Sudah dicatat</option><option value="open">Belum dicatat</option></select></div>
            {importError && <div className="form-alert" role="alert" data-testid="excel-import-error">{importError}</div>}
            <div className="table-shell">
              <table className="journal-table"><thead><tr><th>No.</th><th>Tanggal</th><th>Hari</th><th>Profit aktual · USC</th><th>Profit aktual · IDR</th><th>Saldo aktual · USC</th><th>Saldo aktual · IDR</th><th>Profit %</th><th>Target profit</th><th>Saldo target · USC</th><th>Saldo target · IDR</th><th>Status</th><th>Prestasi</th><th>Catatan</th></tr></thead>
                <tbody>{shownDays.map((day)=><tr key={day.number} className={day.milestone?'milestone-row':day.number===nextDay.number?'today-row':''} data-testid={`row-journal-${day.number}`}>
                  <td className="mono muted">{String(day.number).padStart(2,'0')}</td><td>{dateLabel(day.date)}</td><td className="muted">{day.weekday}</td>
                  <td><label className="sr-only" htmlFor={`profit-${day.number}`}>Profit aktual USC, hari {day.number}</label><input id={`profit-${day.number}`} className="input-inline" type="number" inputMode="decimal" step="0.01" value={day.profitUSC??''} placeholder="Belum dicatat" onChange={(event)=>journal.updateProfit(day.number-1,event.target.value)} data-testid={`input-profit-${day.number}`} /></td>
                  <td className="mono">{moneyIDR(day.profitIDR)}</td><td className="mono">{moneyUSC(day.actualBalanceUSC)}</td><td className="mono">{moneyIDR(day.actualBalanceIDR)}</td><td className="mono muted">{day.profitPercent===null?'—':percent(day.profitPercent)}</td>
                  <td className="mono">{moneyUSC(day.targetProfitUSC)}</td><td className="mono">{moneyUSC(day.targetBalanceUSC)}</td><td className="mono">{moneyIDR(day.targetBalanceIDR)}</td>
                  <td>{day.targetMet===null?<span className="status-pill pending">Belum dinilai</span>:<span className={`status-pill ${day.targetMet?'':'pending'}`}>{day.targetMet?'Terpenuhi':'Belum'}</span>}</td><td>{day.milestone?<span className="achievement-pill"><Icon name="award" /> Rp100 jt</span>:<span className="muted">—</span>}</td>
                  <td><label className="sr-only" htmlFor={`note-${day.number}`}>Catatan trading hari {day.number}</label><input id={`note-${day.number}`} className="input-inline note-input" type="text" maxLength={2000} value={entries[day.number-1]?.note??''} placeholder="Catatan sesi…" onChange={(event)=>journal.updateNote(day.number-1,event.target.value)} data-testid={`input-note-${day.number}`} /></td>
                </tr>)}</tbody>
              </table>
              <div className="journal-mobile">{shownDays.map((day)=><article className={`glass journal-card ${day.milestone?'milestone-card':''}`} key={day.number} data-testid={`card-journal-${day.number}`}>
                <div className="journal-card-head"><strong>{dateLabel(day.date)} <span className="muted">· {day.weekday}</span></strong><span className="mono muted">#{String(day.number).padStart(2,'0')}</span></div>
                <div className="journal-card-fields">
                  <label>Profit aktual · USC<input className="input-inline" type="number" inputMode="decimal" step="0.01" value={day.profitUSC??''} placeholder="Profit bersih" onChange={(event)=>journal.updateProfit(day.number-1,event.target.value)} data-testid={`input-profit-mobile-${day.number}`} /></label>
                  <div className="journal-value"><span>Profit aktual · IDR</span><strong>{moneyIDR(day.profitIDR)}</strong></div><div className="journal-value"><span>Saldo aktual · USC</span><strong>{moneyUSC(day.actualBalanceUSC)}</strong></div><div className="journal-value"><span>Saldo aktual · IDR</span><strong>{moneyIDR(day.actualBalanceIDR)}</strong></div><div className="journal-value"><span>Profit %</span><strong>{day.profitPercent===null?'—':percent(day.profitPercent)}</strong></div><div className="journal-value"><span>Target profit</span><strong>{moneyUSC(day.targetProfitUSC)}</strong></div><div className="journal-value"><span>Saldo target · USC</span><strong>{moneyUSC(day.targetBalanceUSC)}</strong></div><div className="journal-value"><span>Saldo target · IDR</span><strong>{moneyIDR(day.targetBalanceIDR)}</strong></div><div className="journal-value"><span>Status target</span><strong>{day.targetMet===null?'Belum dinilai':day.targetMet?'Terpenuhi':'Belum tercapai'}</strong></div><div className="journal-value"><span>Prestasi</span><strong>{day.milestone?<span className="achievement-pill"><Icon name="award" /> Rp100 juta</span>:'—'}</strong></div>
                  <label className="note-label">Catatan<input className="input-inline note-input" type="text" maxLength={2000} value={entries[day.number-1]?.note??''} placeholder="Catatan sesi…" onChange={(event)=>journal.updateNote(day.number-1,event.target.value)} data-testid={`input-note-mobile-${day.number}`} /></label>
                </div>
              </article>)}</div>
              {!shownDays.length && <div className="empty-state">Tidak ada hari yang sesuai filter.</div>}
            </div>
          </article>
        </section>}

        {view==='analytics' && <section>
          <div className="page-heading"><div><div className="eyebrow">Performance · actual versus plan</div><h1>Analitik</h1><p className="page-subtitle">Pola, target, dan momentum dalam satu pandangan.</p></div><div className="date-stamp">{summary.daysFilled} hari dengan hasil aktual</div></div>
          <div className="stats-strip"><article className="glass small-stat"><span>Total profit bersih</span><strong className={summary.totalProfitUSC>=0?'positive':'negative'}>{moneyUSC(summary.totalProfitUSC)}</strong></article><article className="glass small-stat"><span>Saldo sekarang</span><strong>{moneyUSC(currentBalance)}</strong></article><article className="glass small-stat"><span>Target tercapai</span><strong>{summary.daysMet} <small className="muted">/ {summary.daysFilled}</small></strong></article><article className="glass small-stat"><span>Gap ke target berikutnya</span><strong>{moneyUSC(summary.targetGapUSC)}</strong></article></div>
          <div className="analytics-grid">
            <article className="glass panel"><div className="panel-head"><div><h2 className="panel-title">Saldo aktual dan rencana</h2><div className="panel-note">Arah pertumbuhan pada hari tercatat</div></div><div className="legend"><span><i /> Aktual</span><span className="target"><i /> Target</span></div></div><BalanceChart days={days} parameters={parameters} /></article>
            <article className="glass panel goal-panel analytics-milestone"><div><div className="panel-head"><div><h2 className="panel-title">Menuju Rp100 juta</h2><div className="panel-note">Performa aktual dalam rupiah</div></div><Icon name="target" /></div><div className="milestone-number">{percent(progress)} <span>tercapai</span></div><div className="progress-track"><span style={{width:`${progress}%`}} /></div></div><div className="milestone-copy"><strong>{summary.targetMilestone?`Target proyeksi pada hari ${summary.targetMilestone.number}`:'Proyeksi belum menyentuh milestone'}</strong><p>Saldo aktual saat ini {moneyIDR(currentIDR)}; proyeksi target 130 hari {moneyIDR(days[days.length-1].targetBalanceIDR)}.</p></div></article>
            <article className="glass panel chart-wide"><div className="panel-head"><div><h2 className="panel-title">Profit harian</h2><div className="panel-note">Bilah menunjukkan hasil bersih setiap hari tercatat</div></div></div><DailyProfitChart days={days} /></article>
            <article className="glass panel chart-wide"><div className="panel-head"><div><h2 className="panel-title">Peta hasil harian</h2><div className="panel-note">Arahkan atau fokuskan hari untuk melihat profit dan pencapaian</div></div><span className="heatmap-count">{summary.daysFilled} hari terisi</span></div><Heatmap days={days} /></article>
          </div>
          <div className="streak-grid">
            <article className="glass streak-card"><span className="streak-icon"><Icon name="award" /></span><div><span className="streak-label">Ritme saat ini</span><strong>{streak.current} <small>hari target beruntun</small></strong><p>{streak.current ? 'Momentum disiplin Anda masih berjalan.' : 'Rangkaian baru dimulai saat target harian tercapai.'}</p></div></article>
            <article className="glass streak-card gold-streak"><span className="streak-icon"><Icon name="target" /></span><div><span className="streak-label">Rekor pencapaian</span><strong>{streak.best} <small>hari berturut-turut</small></strong><p>Target majemuk tercapai pada hasil yang tercatat.</p></div></article>
          </div>
        </section>}

        {view==='settings' && <section>
          <div className="page-heading"><div><div className="eyebrow">Account, appearance, compound model</div><h1>Pengaturan</h1><p className="page-subtitle">Kendali atas akun, tampilan, dan asumsi perhitungan Anda.</p></div></div>
          <div className="settings-grid">
            <article className="glass panel"><div className="panel-head"><div><h2 className="panel-title">Parameter compound</h2><div className="panel-note">Pembaruan langsung menghitung ulang 130 hari.</div></div></div><div className="settings-fields">
              <div className="field"><label htmlFor="param-initial">Saldo awal · USC</label><input id="param-initial" type="number" min="0" step=".01" value={parameters.initialBalanceUSC} onChange={(event)=>journal.updateParameter('initialBalanceUSC',event.target.value===''?0:Number(event.target.value))} data-testid="input-initial-balance" /></div>
              <div className="field"><label htmlFor="param-rate">Target pertumbuhan harian · %</label><input id="param-rate" type="number" min="0" max="100" step=".1" value={parameters.targetRate*100} onChange={(event)=>journal.updateParameter('targetRate',event.target.value===''?0:Number(event.target.value)/100)} data-testid="input-target-rate" /><span className="field-help">Nilai disimpan sebagai desimal.</span></div>
              <div className="field"><label htmlFor="param-exchange">Kurs IDR per USC</label><input id="param-exchange" type="number" min="0" step="1" value={parameters.exchangeRateIDR} onChange={(event)=>journal.updateParameter('exchangeRateIDR',event.target.value===''?0:Number(event.target.value))} data-testid="input-exchange-rate" /></div>
              <div className="field"><label htmlFor="param-start">Tanggal mulai jurnal</label><input id="param-start" type="date" value={parameters.startDate} onChange={(event)=>{if(event.target.value) journal.updateParameter('startDate',event.target.value);}} data-testid="input-start-date" /><span className="field-help">Hari kerja Senin sampai Jumat, tanpa kalender libur.</span></div>
            </div><div className="settings-tip"><strong>Compound, satu hari pada satu waktu.</strong>Target saldo dihitung dari saldo target hari sebelumnya dikalikan laju harian. Profit aktual selalu mencerminkan hasil yang Anda catat.</div></article>
            <div className="settings-stack">
              <AccountSettings name={user.name} onNotice={notify} onLogout={onLogout} />
              <article className="glass panel"><div className="panel-head"><div><h2 className="panel-title">Tampilan</h2><div className="panel-note">Pilih suasana workspace Anda.</div></div></div><div className="theme-options" role="group" aria-label="Appearance mode">{([{id:'system',label:'Sistem',icon:'device'},{id:'light',label:'Terang',icon:'sun'},{id:'dark',label:'Gelap',icon:'moon'}] as const).map((option)=><button key={option.id} className={`theme-option ${journal.appearanceMode===option.id?'selected':''}`} type="button" onClick={()=>journal.setAppearanceMode(option.id)} aria-pressed={journal.appearanceMode===option.id} data-testid={`button-theme-${option.id}`}><Icon name={option.icon} /><span>{option.label}</span></button>)}</div></article>
              <article className="glass panel"><div className="panel-head"><div><h2 className="panel-title">Data dan transfer</h2><div className="panel-note">Pindahkan workbook atau bawa catatan browser lama.</div></div></div>
                {legacy && <div className="legacy-transfer-card"><div><strong>Jurnal browser tersedia</strong><span>{legacy.entries.filter((row)=>row.profitUSC!==null||row.note.trim()).length} hari dengan data</span></div><button type="button" className="button" onClick={transferLegacy} disabled={importMutation.isPending} data-testid="button-transfer-from-settings">{importMutation.isPending?<span className="button-loader" />:<><Icon name="download" /> Transfer</>}</button></div>}
                {importError&&<div className="form-alert" role="alert">{importError}</div>}
                <div className="settings-actions"><button className="button" type="button" onClick={()=>void doExport()} data-testid="button-settings-export"><Icon name="download" /> Ekspor Excel</button><button className="button" type="button" onClick={()=>uploadRef.current?.click()} data-testid="button-settings-import"><Icon name="upload" /> Impor Excel</button></div>
              </article>
            </div>
          </div>
          <article className="glass logout-panel"><div><h2 className="panel-title">Akun ini tetap privat</h2><p>Keluar akan mengakhiri sesi pada perangkat ini. Jurnal tetap tersimpan di akun {user.name}.</p></div><button className="button logout-button" type="button" onClick={onLogout} data-testid="button-logout"><Icon name="logout" /> Keluar</button></article>
        </section>}
      </div>
    </main>
    <nav className="mobile-nav" aria-label="Navigasi bawah">{navItems.map((item)=><button key={item.id} type="button" className={`nav-item ${view===item.id?'active':''}`} onClick={()=>setView(item.id)} data-testid={`mobile-nav-${item.id}`} aria-current={view===item.id?'page':undefined}><Icon name={item.icon} />{item.label}</button>)}</nav>
  </div>;
}

function AccountSettings({ name, onNotice, onLogout }: { name: string; onNotice: (message: string) => void; onLogout: () => void }) {
  const client = useQueryClient();
  const changeName = useChangeAccountName();
  const changePin = useChangeAccountPin();
  const [accountName,setAccountName] = useState(name);
  const [currentPin,setCurrentPin] = useState('');
  const [newPin,setNewPin] = useState('');
  const [confirmPin,setConfirmPin] = useState('');
  const [accountError,setAccountError] = useState('');
  const [pinError,setPinError] = useState('');
  useEffect(()=>setAccountName(name),[name]);
  const saveName=(event:FormEvent<HTMLFormElement>)=>{
    event.preventDefault();setAccountError('');
    if(accountName.trim().length<2){setAccountError('Nama akun minimal dua karakter.');return;}
    changeName.mutate({data:{name:accountName.trim()}},{onSuccess:(response)=>{client.setQueryData(getGetCurrentUserQueryKey(),response);onNotice('Nama akun berhasil diperbarui.');},onError:(error)=>setAccountError(errorMessage(error,'Nama akun belum dapat diperbarui.'))});
  };
  const savePin=(event:FormEvent<HTMLFormElement>)=>{
    event.preventDefault();setPinError('');
    if(!/^\d{4,6}$/.test(currentPin)||!/^\d{4,6}$/.test(newPin)){setPinError('PIN harus terdiri dari 4 sampai 6 angka.');return;}
    if(newPin!==confirmPin){setPinError('Konfirmasi PIN belum sama.');return;}
    changePin.mutate({data:{currentPin,newPin}},{onSuccess:()=>{setCurrentPin('');setNewPin('');setConfirmPin('');onNotice('PIN berhasil diganti.');},onError:(error)=>setPinError(errorMessage(error,'PIN belum dapat diperbarui.'))});
  };
  return <article className="glass panel account-settings">
    <div className="panel-head"><div><h2 className="panel-title">Akun Rizal</h2><div className="panel-note">Pengaturan identitas dan keamanan.</div></div><Icon name="secure" /></div>
    <form className="account-form" onSubmit={saveName}><div className="field"><label htmlFor="account-name">Nama akun</label><input id="account-name" type="text" minLength={2} maxLength={60} value={accountName} onChange={(event)=>setAccountName(event.target.value)} data-testid="input-account-name" /></div><button className="button" type="submit" disabled={changeName.isPending} data-testid="button-save-account-name">{changeName.isPending?'Menyimpan':'Simpan nama'}</button></form>
    {accountError&&<div className="form-alert" role="alert">{accountError}</div>}
    <form className="pin-form" onSubmit={savePin}><div className="field"><label htmlFor="current-pin">PIN saat ini</label><input id="current-pin" type="password" inputMode="numeric" pattern="[0-9]{4,6}" minLength={4} maxLength={6} autoComplete="current-password" value={currentPin} onChange={(event)=>setCurrentPin(event.target.value.replace(/\D/g,'').slice(0,6))} data-testid="input-current-pin" /></div><div className="field"><label htmlFor="new-pin">PIN baru</label><input id="new-pin" type="password" inputMode="numeric" pattern="[0-9]{4,6}" minLength={4} maxLength={6} autoComplete="new-password" value={newPin} onChange={(event)=>setNewPin(event.target.value.replace(/\D/g,'').slice(0,6))} data-testid="input-new-pin" /></div><div className="field"><label htmlFor="confirm-pin">Ulangi PIN baru</label><input id="confirm-pin" type="password" inputMode="numeric" pattern="[0-9]{4,6}" minLength={4} maxLength={6} autoComplete="new-password" value={confirmPin} onChange={(event)=>setConfirmPin(event.target.value.replace(/\D/g,'').slice(0,6))} data-testid="input-confirm-pin" /></div><button className="button" type="submit" disabled={changePin.isPending} data-testid="button-change-pin">{changePin.isPending?'Memperbarui':'Ganti PIN'}</button></form>
    {pinError&&<div className="form-alert" role="alert">{pinError}</div>}
  </article>;
}

function AuthenticatedGate({ user, onLogout }: { user: { id: string; name: string }; onLogout: () => void }) {
  const client=useQueryClient();
  const remote=useGetJournal({query:{queryKey:getGetJournalQueryKey(),retry:false,refetchOnMount:'always',staleTime:0}});
  const transfer=useImportBrowserJournal();
  const [gate,setGate]=useState<'checking'|'prompt'|'resolved'>('checking');
  const [legacy,setLegacy]=useState<LegacyJournal|null>(null);
  const [transferError,setTransferError]=useState('');
  useEffect(()=>{
    if(!remote.isSuccess||gate!=='checking')return;
    const found=legacyJournal();
    if(!remote.data.journal&&found){setLegacy(found);setGate('prompt');}
    else setGate('resolved');
  },[gate,remote.data,remote.isSuccess]);
  const doTransfer=()=>{
    if(!legacy)return;
    setTransferError('');
    transfer.mutate({data:{journal:apiDocument(legacy)}},{
      onSuccess:(result)=>{
        try{window.localStorage.removeItem(LEGACY_KEY);}catch{/* Browser storage may be unavailable. */}
        client.setQueryData(getGetJournalQueryKey(),{journal:result.journal,hasExistingRemoteData:true});
        setGate('resolved');
      },
      onError:(error)=>setTransferError(errorMessage(error,'Transfer belum berhasil. Catatan browser tetap utuh.')),
    });
  };
  if(remote.isLoading||gate==='checking')return <LoadingPanel label="Memeriksa ruang jurnal" />;
  if(remote.isError)return <div className="auth-error glass"><Icon name="secure" /><h1>Jurnal tidak dapat dimuat</h1><p>Sesi akun tersedia, tetapi server belum mengirim jurnal.</p><button type="button" className="button primary" onClick={()=>void remote.refetch()} data-testid="button-retry-auth-journal"><Icon name="retry" /> Coba lagi</button></div>;
  if(gate==='prompt'&&legacy)return <TransferPrompt source={legacy} busy={transfer.isPending} error={transferError} onTransfer={doTransfer} onDecline={()=>setGate('resolved')} />;
  return <AppContent user={user} onLogout={onLogout} />;
}

function AppRoot() {
  const client=useQueryClient();
  const current=useGetCurrentUser({query:{queryKey:getGetCurrentUserQueryKey(),retry:false,refetchOnMount:'always',staleTime:0}});
  const logout=useLogout();
  const [loggedOut,setLoggedOut]=useState(false);
  const onLogout=()=>{
    logout.mutate(undefined,{onSuccess:()=>{
      client.removeQueries({queryKey:getGetJournalQueryKey()});
      setLoggedOut(true);
      document.documentElement.dataset.theme='light';
    }});
  };
  const onLoginSuccess=()=>{
    setLoggedOut(false);
    void client.invalidateQueries({queryKey:getGetJournalQueryKey()});
  };
  if(current.isLoading)return <LoadingPanel label="Membuka workspace privat" />;
  if(current.data?.user&&!loggedOut)return <AuthenticatedGate key={current.data.user.id} user={current.data.user} onLogout={onLogout} />;
  const failure=current.error as {status?:number}|null;
  if(!loggedOut&&current.isError&&failure?.status!==401&&failure?.status!==403)return <div className="auth-error glass"><Icon name="secure" /><h1>Workspace belum terhubung</h1><p>Belum ada koneksi ke server jurnal. Periksa koneksi lalu coba kembali.</p><button type="button" className="button primary" onClick={()=>void current.refetch()} data-testid="button-retry-session"><Icon name="retry" /> Coba lagi</button></div>;
  return <LoginScreen onSuccess={onLoginSuccess} />;
}

function App() {
  return <QueryClientProvider client={queryClient}><AppRoot /></QueryClientProvider>;
}

export default App;
