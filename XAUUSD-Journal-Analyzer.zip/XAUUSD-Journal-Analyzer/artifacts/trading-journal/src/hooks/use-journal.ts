import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import {
  getGetJournalQueryKey,
  useGetJournal,
  useSaveJournal,
} from '@workspace/api-client-react';
import {
  calculateJournal,
  createDefaultJournal,
  type DailyEntry,
  type JournalParameters,
} from '@/domain/journal';

export type AppearanceMode = 'system' | 'light' | 'dark';
export type ParameterKey = keyof JournalParameters;
export type JournalSaveStatus = 'loading' | 'saved' | 'saving' | 'unsaved' | 'error';

export interface JournalDocumentState {
  parameters: JournalParameters;
  entries: DailyEntry[];
  appearanceMode: AppearanceMode;
}

function coerceDate(value: unknown, fallback: string): string {
  if (value instanceof Date && !Number.isNaN(value.getTime())) {
    return value.toISOString().slice(0, 10);
  }
  if (typeof value === 'string' && /^\d{4}-\d{2}-\d{2}/.test(value)) {
    return value.slice(0, 10);
  }
  return fallback;
}

function normalizeDocument(value: unknown): JournalDocumentState {
  const defaults = createDefaultJournal();
  if (!value || typeof value !== 'object') {
    return { ...defaults, appearanceMode: 'system' };
  }
  const candidate = value as Partial<JournalDocumentState>;
  const sourceParameters = candidate.parameters;
  const parameters: JournalParameters = {
    initialBalanceUSC:
      typeof sourceParameters?.initialBalanceUSC === 'number' && Number.isFinite(sourceParameters.initialBalanceUSC)
        ? sourceParameters.initialBalanceUSC : defaults.parameters.initialBalanceUSC,
    exchangeRateIDR:
      typeof sourceParameters?.exchangeRateIDR === 'number' && Number.isFinite(sourceParameters.exchangeRateIDR)
        ? sourceParameters.exchangeRateIDR : defaults.parameters.exchangeRateIDR,
    targetRate:
      typeof sourceParameters?.targetRate === 'number' && Number.isFinite(sourceParameters.targetRate)
        ? sourceParameters.targetRate : defaults.parameters.targetRate,
    startDate: coerceDate(sourceParameters?.startDate, defaults.parameters.startDate),
  };
  const entries = Array.from({ length: 130 }, (_, index) => {
    const row = candidate.entries?.[index];
    return {
      profitUSC: typeof row?.profitUSC === 'number' && Number.isFinite(row.profitUSC) ? row.profitUSC : null,
      note: typeof row?.note === 'string' ? row.note.slice(0, 2000) : '',
    };
  });
  const appearanceMode = candidate.appearanceMode === 'light' || candidate.appearanceMode === 'dark'
    ? candidate.appearanceMode : 'system';
  return { parameters, entries, appearanceMode };
}

function toRequestDocument(document: JournalDocumentState) {
  return {
    parameters: {
      ...document.parameters,
      startDate: new Date(`${document.parameters.startDate}T00:00:00.000Z`),
    },
    entries: document.entries,
    appearanceMode: document.appearanceMode,
  };
}

export function useJournal() {
  const client = useQueryClient();
  const remote = useGetJournal({
    query: {
      queryKey: getGetJournalQueryKey(),
      retry: false,
      refetchOnMount: 'always',
      refetchOnWindowFocus: true,
      staleTime: 0,
    },
  });
  const saveMutation = useSaveJournal();
  const [document, setDocument] = useState<JournalDocumentState>(() => ({
    ...createDefaultJournal(),
    appearanceMode: 'system',
  }));
  const [ready, setReady] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [saveError, setSaveError] = useState('');
  const revision = useRef(0);
  const initialised = useRef(false);

  useEffect(() => {
    if (!remote.isSuccess || initialised.current) return;
    const received = remote.data.journal
      ? normalizeDocument(remote.data.journal)
      : normalizeDocument(createDefaultJournal());
    setDocument(received);
    initialised.current = true;
    setReady(true);
  }, [remote.data, remote.isSuccess]);

  useEffect(() => {
    if (!ready || !dirty || !remote.isSuccess) return;
    const capturedRevision = revision.current;
    const timer = window.setTimeout(() => {
      setSaveError('');
      saveMutation.mutate(
        { data: { journal: toRequestDocument(document) } },
        {
          onSuccess: (result) => {
            client.setQueryData(getGetJournalQueryKey(), {
              journal: result.journal,
              hasExistingRemoteData: true,
            });
            if (revision.current === capturedRevision) setDirty(false);
          },
          onError: (error) => {
            setSaveError(error instanceof Error ? error.message : 'Perubahan belum tersimpan.');
          },
        },
      );
    }, 650);
    return () => window.clearTimeout(timer);
  }, [client, document, dirty, ready, remote.isSuccess, saveMutation.mutate]);

  const markChanged = useCallback((transform: (current: JournalDocumentState) => JournalDocumentState) => {
    revision.current += 1;
    setDocument((current) => transform(current));
    setDirty(true);
    setSaveError('');
  }, []);

  const updateParameter = useCallback(<K extends ParameterKey>(key: K, value: JournalParameters[K]) => {
    markChanged((current) => ({
      ...current,
      parameters: { ...current.parameters, [key]: value },
    }));
  }, [markChanged]);

  const updateProfit = useCallback((index: number, rawString: string) => {
    const trimmed = rawString.trim();
    const parsed = trimmed === '' ? null : Number(trimmed);
    const profitUSC = parsed === null || Number.isFinite(parsed) ? parsed : null;
    markChanged((current) => ({
      ...current,
      entries: current.entries.map((entry, i) => i === index ? { ...entry, profitUSC } : entry),
    }));
  }, [markChanged]);

  const updateNote = useCallback((index: number, note: string) => {
    markChanged((current) => ({
      ...current,
      entries: current.entries.map((entry, i) => i === index ? { ...entry, note: note.slice(0, 2000) } : entry),
    }));
  }, [markChanged]);

  const replaceJournal = useCallback((next: {
    parameters: JournalParameters;
    entries: DailyEntry[];
    appearanceMode?: AppearanceMode;
  }) => {
    markChanged((current) => normalizeDocument({
      ...next,
      appearanceMode: next.appearanceMode ?? current.appearanceMode,
    }));
  }, [markChanged]);

  const setAppearanceMode = useCallback((appearanceMode: AppearanceMode) => {
    markChanged((current) => ({ ...current, appearanceMode }));
  }, [markChanged]);

  const calculated = useMemo(
    () => calculateJournal(document.parameters, document.entries),
    [document.parameters, document.entries],
  );

  const saveStatus: JournalSaveStatus = !ready
    ? 'loading'
    : saveError
      ? 'error'
      : saveMutation.isPending
        ? 'saving'
        : dirty
          ? 'unsaved'
          : 'saved';

  return {
    ...document,
    days: calculated.days,
    summary: calculated.summary,
    ready,
    loading: remote.isLoading || !ready,
    error: remote.error,
    refetch: remote.refetch,
    saveStatus,
    saveError,
    updateParameter,
    updateProfit,
    updateNote,
    replaceJournal,
    setAppearanceMode,
  };
}
