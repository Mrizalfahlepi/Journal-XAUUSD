export const JOURNAL_DAYS = 130;
export const MILESTONE_IDR = 100_000_000;

export interface JournalParameters {
  initialBalanceUSC: number;
  exchangeRateIDR: number;
  targetRate: number;
  startDate: string;
}

export interface DailyEntry {
  profitUSC: number | null;
  note: string;
}

export interface CalculatedDay {
  number: number;
  date: string;
  weekday: string;
  profitUSC: number | null;
  profitIDR: number | null;
  actualBalanceUSC: number | null;
  actualBalanceIDR: number | null;
  profitPercent: number | null;
  targetMet: boolean | null;
  targetProfitUSC: number;
  targetBalanceUSC: number;
  targetBalanceIDR: number;
  milestone: boolean;
}

export interface JournalSummary {
  totalProfitUSC: number;
  totalProfitIDR: number;
  actualBalanceUSC: number;
  actualBalanceIDR: number;
  totalProfitPercent: number;
  daysFilled: number;
  daysMet: number;
  currentTargetProfitUSC: number;
  currentTargetBalanceUSC: number;
  currentTargetBalanceIDR: number;
  targetGapUSC: number;
  positionVsTargetUSC: number;
  actualProgressPercent: number;
  targetMilestone: CalculatedDay | null;
  nextEntry: CalculatedDay;
  lastFilled: CalculatedDay | null;
}

export interface CalculatedJournal {
  days: CalculatedDay[];
  summary: JournalSummary;
}

export const DEFAULT_PARAMETERS: JournalParameters = {
  initialBalanceUSC: 2503,
  exchangeRateIDR: 179,
  targetRate: 0.05,
  startDate: "2026-10-01",
};

export const DEFAULT_ENTRIES: DailyEntry[] = Array.from(
  { length: JOURNAL_DAYS },
  (_, index) => {
    if (index === 0) {
      return {
        profitUSC: 140.7,
        note: "2 trade: +79,30 dan +61,40",
      };
    }
    if (index === 1) {
      return {
        profitUSC: 422,
        note: "3 trade: -6,40 / +235,90 / -39,10",
      };
    }
    if (index === 2) {
      return { profitUSC: 292, note: "" };
    }
    return { profitUSC: null, note: "" };
  },
);

const INDONESIAN_WEEKDAYS = [
  "Minggu",
  "Senin",
  "Selasa",
  "Rabu",
  "Kamis",
  "Jumat",
  "Sabtu",
];

function parseLocalDate(isoDate: string): Date {
  const [year, month, day] = isoDate.split("-").map(Number);
  return new Date(Date.UTC(year, month - 1, day));
}

function dateToISO(date: Date): string {
  return date.toISOString().slice(0, 10);
}

function nextWeekday(date: Date): Date {
  const next = new Date(date);
  do {
    next.setUTCDate(next.getUTCDate() + 1);
  } while (next.getUTCDay() === 0 || next.getUTCDay() === 6);
  return next;
}

function buildDates(startDate: string): string[] {
  const dates = [dateToISO(parseLocalDate(startDate))];
  for (let index = 1; index < JOURNAL_DAYS; index += 1) {
    dates.push(dateToISO(nextWeekday(parseLocalDate(dates[index - 1]))));
  }
  return dates;
}

/**
 * Recalculates the journal from its editable inputs. Daily return is measured
 * against the balance before that day's profit; target balances compound daily.
 */
export function calculateJournal(
  parameters: JournalParameters,
  entries: DailyEntry[],
): CalculatedJournal {
  const dates = buildDates(parameters.startDate);
  const safeEntries = Array.from({ length: JOURNAL_DAYS }, (_, index) => {
    const entry = entries[index];
    return {
      profitUSC:
        entry && Number.isFinite(entry.profitUSC)
          ? entry.profitUSC
          : null,
      note: entry?.note ?? "",
    };
  });

  let runningProfit = 0;
  let targetBalance = parameters.initialBalanceUSC;

  const days = safeEntries.map((entry, index): CalculatedDay => {
    const beforeBalance = parameters.initialBalanceUSC + runningProfit;
    const targetProfitUSC = targetBalance * parameters.targetRate;
    targetBalance += targetProfitUSC;

    const hasProfit = entry.profitUSC !== null;
    if (entry.profitUSC !== null) {
      runningProfit += entry.profitUSC;
    }
    const actualBalanceUSC = hasProfit
      ? parameters.initialBalanceUSC + runningProfit
      : null;
    const profitPercent =
      hasProfit && beforeBalance !== 0
        ? (entry.profitUSC! / beforeBalance) * 100
        : null;

    return {
      number: index + 1,
      date: dates[index],
      weekday: INDONESIAN_WEEKDAYS[parseLocalDate(dates[index]).getUTCDay()],
      profitUSC: entry.profitUSC,
      profitIDR:
        hasProfit ? entry.profitUSC! * parameters.exchangeRateIDR : null,
      actualBalanceUSC,
      actualBalanceIDR:
        actualBalanceUSC === null
          ? null
          : actualBalanceUSC * parameters.exchangeRateIDR,
      profitPercent,
      targetMet:
        profitPercent === null ? null : profitPercent >= parameters.targetRate * 100,
      targetProfitUSC,
      targetBalanceUSC: targetBalance,
      targetBalanceIDR: targetBalance * parameters.exchangeRateIDR,
      milestone: false,
    };
  });

  const milestoneIndex = days.findIndex(
    (day) => day.targetBalanceIDR >= MILESTONE_IDR,
  );
  if (milestoneIndex >= 0) {
    days[milestoneIndex] = { ...days[milestoneIndex], milestone: true };
  }

  const totalProfitUSC = safeEntries.reduce(
    (total, entry) => total + (entry.profitUSC ?? 0),
    0,
  );
  const actualBalanceUSC = parameters.initialBalanceUSC + totalProfitUSC;
  const daysFilled = safeEntries.filter(
    (entry) => entry.profitUSC !== null,
  ).length;
  const daysMet = days.filter((day) => day.targetMet === true).length;
  const lastFilledIndex = safeEntries.reduce(
    (lastIndex, entry, index) =>
      entry.profitUSC === null ? lastIndex : index,
    -1,
  );
  const nextEntryIndex = safeEntries.findIndex(
    (entry) => entry.profitUSC === null,
  );
  const lastFilled = lastFilledIndex >= 0 ? days[lastFilledIndex] : null;
  const nextEntry = days[nextEntryIndex >= 0 ? nextEntryIndex : days.length - 1];
  const currentTargetDay = lastFilled ?? days[0];
  const targetComparisonDay =
    daysFilled > 0 ? days[daysFilled - 1] : null;
  const positionVsTargetUSC =
    targetComparisonDay === null
      ? 0
      : actualBalanceUSC - targetComparisonDay.targetBalanceUSC;

  return {
    days,
    summary: {
      totalProfitUSC,
      totalProfitIDR: totalProfitUSC * parameters.exchangeRateIDR,
      actualBalanceUSC,
      actualBalanceIDR: actualBalanceUSC * parameters.exchangeRateIDR,
      totalProfitPercent:
        parameters.initialBalanceUSC === 0
          ? 0
          : (totalProfitUSC / parameters.initialBalanceUSC) * 100,
      daysFilled,
      daysMet,
      currentTargetProfitUSC: nextEntry.targetProfitUSC,
      currentTargetBalanceUSC: nextEntry.targetBalanceUSC,
      currentTargetBalanceIDR: nextEntry.targetBalanceIDR,
      targetGapUSC:
        nextEntry.targetBalanceUSC - actualBalanceUSC,
      positionVsTargetUSC,
      actualProgressPercent:
        (actualBalanceUSC * parameters.exchangeRateIDR) / MILESTONE_IDR * 100,
      targetMilestone: milestoneIndex >= 0 ? days[milestoneIndex] : null,
      nextEntry,
      lastFilled,
    },
  };
}

export function createDefaultJournal(): {
  parameters: JournalParameters;
  entries: DailyEntry[];
} {
  return {
    parameters: { ...DEFAULT_PARAMETERS },
    entries: DEFAULT_ENTRIES.map((entry) => ({ ...entry })),
  };
}
