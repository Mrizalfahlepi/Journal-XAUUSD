import { Router, type IRouter } from "express";
import authRouter from "./auth";
import healthRouter from "./health";
import journalRouter from "./journal";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(journalRouter);

export default router;
