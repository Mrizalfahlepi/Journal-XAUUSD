import { Router, type IRouter } from "express";
import { and, eq, sql } from "drizzle-orm";
import {
  GetJournalResponse,
  ImportBrowserJournalBody,
  ImportBrowserJournalResponse,
  SaveJournalBody,
  SaveJournalResponse,
} from "@workspace/api-zod";
import { db, journalEntriesTable, journalProfilesTable } from "@workspace/db";
import { requireSession } from "../lib/auth";

const router: IRouter = Router();

function dateOnly(value: Date | string) {
  if (value instanceof Date) return value.toISOString().slice(0, 10);
  return value.slice(0, 10);
}

async function readJournal(userId: string) {
  const [profile] = await db
    .select()
    .from(journalProfilesTable)
    .where(eq(journalProfilesTable.userId, userId))
    .limit(1);
  const storedEntries = await db
    .select()
    .from(journalEntriesTable)
    .where(eq(journalEntriesTable.userId, userId))
    .orderBy(journalEntriesTable.dayNumber);
  const hasExistingRemoteData = Boolean(profile || storedEntries.length);

  if (!profile) return { journal: null, hasExistingRemoteData };

  const entries = Array.from({ length: 130 }, (_, index) => {
    const stored = storedEntries.find((entry) => entry.dayNumber === index + 1);
    return {
      profitUSC: stored?.profitUSC ?? null,
      note: stored?.note ?? "",
    };
  });

  return {
    journal: {
      parameters: {
        initialBalanceUSC: profile.initialBalanceUSC,
        exchangeRateIDR: profile.exchangeRateIDR,
        targetRate: profile.targetRate,
        startDate: new Date(`${profile.startDate}T00:00:00.000Z`),
      },
      entries,
      appearanceMode: profile.appearanceMode,
    },
    hasExistingRemoteData,
  };
}

async function upsertProfile(userId: string, journal: ReturnType<typeof SaveJournalBody.parse>["journal"]) {
  const parameters = journal.parameters;
  await db
    .insert(journalProfilesTable)
    .values({
      userId,
      initialBalanceUSC: parameters.initialBalanceUSC,
      exchangeRateIDR: parameters.exchangeRateIDR,
      targetRate: parameters.targetRate,
      startDate: dateOnly(parameters.startDate),
      appearanceMode: journal.appearanceMode,
    })
    .onConflictDoUpdate({
      target: journalProfilesTable.userId,
      set: {
        initialBalanceUSC: parameters.initialBalanceUSC,
        exchangeRateIDR: parameters.exchangeRateIDR,
        targetRate: parameters.targetRate,
        startDate: dateOnly(parameters.startDate),
        appearanceMode: journal.appearanceMode,
        updatedAt: new Date(),
      },
    });
}

async function replaceEntries(userId: string, journal: ReturnType<typeof SaveJournalBody.parse>["journal"]) {
  await db.delete(journalEntriesTable).where(eq(journalEntriesTable.userId, userId));
  await db.insert(journalEntriesTable).values(
    journal.entries.map((entry, index) => ({
      userId,
      dayNumber: index + 1,
      profitUSC: entry.profitUSC,
      note: entry.note,
    })),
  );
}

router.get("/journal", requireSession, async (req, res) => {
  const response = GetJournalResponse.parse(await readJournal(req.journalAuth!.user.id));
  res.json(response);
});

router.put("/journal", requireSession, async (req, res) => {
  const parsed = SaveJournalBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Journal data is invalid. Check the date, parameters, and 130 entries." });
    return;
  }

  const userId = req.journalAuth!.user.id;
  await db.transaction(async (transaction) => {
    await transaction
      .insert(journalProfilesTable)
      .values({
        userId,
        initialBalanceUSC: parsed.data.journal.parameters.initialBalanceUSC,
        exchangeRateIDR: parsed.data.journal.parameters.exchangeRateIDR,
        targetRate: parsed.data.journal.parameters.targetRate,
        startDate: dateOnly(parsed.data.journal.parameters.startDate),
        appearanceMode: parsed.data.journal.appearanceMode,
      })
      .onConflictDoUpdate({
        target: journalProfilesTable.userId,
        set: {
          initialBalanceUSC: parsed.data.journal.parameters.initialBalanceUSC,
          exchangeRateIDR: parsed.data.journal.parameters.exchangeRateIDR,
          targetRate: parsed.data.journal.parameters.targetRate,
          startDate: dateOnly(parsed.data.journal.parameters.startDate),
          appearanceMode: parsed.data.journal.appearanceMode,
          updatedAt: new Date(),
        },
      });
    await transaction.delete(journalEntriesTable).where(eq(journalEntriesTable.userId, userId));
    await transaction.insert(journalEntriesTable).values(
      parsed.data.journal.entries.map((entry, index) => ({
        userId,
        dayNumber: index + 1,
        profitUSC: entry.profitUSC,
        note: entry.note,
      })),
    );
  });

  res.json(SaveJournalResponse.parse({
    journal: parsed.data.journal,
    savedAt: new Date(),
  }));
});

router.post("/journal/import-browser", requireSession, async (req, res) => {
  const parsed = ImportBrowserJournalBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Browser journal data is invalid. The original browser copy has not been changed." });
    return;
  }

  const userId = req.journalAuth!.user.id;
  let importedEntries = 0;
  let conflicts = 0;
  let settingsImported = false;

  await db.transaction(async (transaction) => {
    const [existingProfile] = await transaction
      .select({ userId: journalProfilesTable.userId })
      .from(journalProfilesTable)
      .where(eq(journalProfilesTable.userId, userId))
      .limit(1);
    if (!existingProfile) {
      const parameters = parsed.data.journal.parameters;
      await transaction.insert(journalProfilesTable).values({
        userId,
        initialBalanceUSC: parameters.initialBalanceUSC,
        exchangeRateIDR: parameters.exchangeRateIDR,
        targetRate: parameters.targetRate,
        startDate: dateOnly(parameters.startDate),
        appearanceMode: parsed.data.journal.appearanceMode,
      });
      settingsImported = true;
    }

    const remoteEntries = await transaction
      .select()
      .from(journalEntriesTable)
      .where(eq(journalEntriesTable.userId, userId));
    const remoteByDay = new Map(remoteEntries.map((entry) => [entry.dayNumber, entry]));
    const incoming = parsed.data.journal.entries.flatMap((entry, index) => {
      const hasLocalData = entry.profitUSC !== null || entry.note.trim().length > 0;
      if (!hasLocalData) return [];

      const dayNumber = index + 1;
      const remote = remoteByDay.get(dayNumber);
      const remoteHasData = Boolean(remote && (remote.profitUSC !== null || remote.note.trim().length > 0));
      if (!remoteHasData) {
        importedEntries += 1;
        return [{ userId, dayNumber, profitUSC: entry.profitUSC, note: entry.note }];
      }
      if (remote!.profitUSC !== entry.profitUSC || remote!.note !== entry.note) conflicts += 1;
      return [];
    });

    if (incoming.length) {
      await transaction
        .insert(journalEntriesTable)
        .values(incoming)
        .onConflictDoUpdate({
          target: [journalEntriesTable.userId, journalEntriesTable.dayNumber],
          set: {
            profitUSC: sql`excluded.profit_usc`,
            note: sql`excluded.note`,
            updatedAt: new Date(),
          },
        });
    }
  });

  const response = ImportBrowserJournalResponse.parse({
    journal: (await readJournal(userId)).journal,
    importedEntries,
    conflicts,
    settingsImported,
  });
  res.json(response);
});

export default router;
