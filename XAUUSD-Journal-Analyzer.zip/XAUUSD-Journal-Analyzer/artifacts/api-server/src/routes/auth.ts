import { Router, type IRouter } from "express";
import { and, eq, ne } from "drizzle-orm";
import {
  ChangeAccountNameBody,
  ChangeAccountNameResponse,
  ChangeAccountPinBody,
  GetCurrentUserResponse,
  LoginBody,
  LoginResponse,
  LogoutResponse,
} from "@workspace/api-zod";
import { db, journalSessionsTable, journalUsersTable } from "@workspace/db";
import {
  clearLoginFailures,
  createSessionToken,
  DUMMY_PIN_HASH,
  ensureInitialAccount,
  getLoginBucketKey,
  getLoginRetryAfter,
  hashPin,
  hashSessionToken,
  requireSession,
  SESSION_COOKIE,
  SESSION_LIFETIME_MS,
  recordFailedLogin,
  verifyPin,
} from "../lib/auth";

const router: IRouter = Router();

function normalizeAccountName(name: string) {
  return name.trim().normalize("NFKC").toLocaleLowerCase();
}

function cookieOptions() {
  return {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax" as const,
    path: "/api",
    maxAge: SESSION_LIFETIME_MS,
  };
}

router.get("/auth/me", requireSession, (req, res) => {
  const response = GetCurrentUserResponse.parse({ user: req.journalAuth!.user });
  res.json(response);
});

router.post("/auth/login", async (req, res) => {
  const parsed = LoginBody.safeParse(req.body);
  if (!parsed.success || !parsed.data.name.trim()) {
    res.status(400).json({ error: "Enter an account name and a 4–6 digit PIN." });
    return;
  }

  const displayName = parsed.data.name.trim().normalize("NFKC");
  const normalizedName = normalizeAccountName(displayName);
  const bucketKey = getLoginBucketKey(normalizedName, req.ip ?? req.socket.remoteAddress ?? "unknown");
  const activeBlock = await getLoginRetryAfter(bucketKey);
  if (activeBlock > 0) {
    res.status(429).json({ error: "Too many attempts. Wait before trying again.", retryAfterSeconds: activeBlock });
    return;
  }

  await ensureInitialAccount();
  const [user] = await db
    .select({ id: journalUsersTable.id, name: journalUsersTable.name, pinHash: journalUsersTable.pinHash })
    .from(journalUsersTable)
    .where(eq(journalUsersTable.normalizedName, normalizedName))
    .limit(1);

  const validPin = await verifyPin(parsed.data.pin, user?.pinHash ?? DUMMY_PIN_HASH);
  if (!user || !validPin) {
    const retryAfter = await recordFailedLogin(bucketKey);
    if (retryAfter > 0) {
      res.status(429).json({ error: "Too many attempts. Wait before trying again.", retryAfterSeconds: retryAfter });
    } else {
      res.status(401).json({ error: "Account name or PIN is incorrect." });
    }
    return;
  }

  await clearLoginFailures(bucketKey);
  const token = createSessionToken();
  await db.insert(journalSessionsTable).values({
    userId: user.id,
    tokenHash: hashSessionToken(token),
    expiresAt: new Date(Date.now() + SESSION_LIFETIME_MS),
  });
  res.cookie(SESSION_COOKIE, token, cookieOptions());
  res.json(LoginResponse.parse({ user: { id: user.id, name: user.name } }));
});

router.post("/auth/logout", async (req, res) => {
  const token = req.cookies?.[SESSION_COOKIE];
  if (typeof token === "string") {
    await db.delete(journalSessionsTable).where(eq(journalSessionsTable.tokenHash, hashSessionToken(token)));
  }
  res.clearCookie(SESSION_COOKIE, { ...cookieOptions(), maxAge: undefined });
  res.status(204).end();
  LogoutResponse.parse(undefined);
});

router.patch("/auth/name", requireSession, async (req, res) => {
  const body = {
    ...req.body,
    name: typeof req.body?.name === "string" ? req.body.name.trim().normalize("NFKC") : req.body?.name,
  };
  const parsed = ChangeAccountNameBody.safeParse(body);
  if (!parsed.success || !parsed.data.name.trim()) {
    res.status(400).json({ error: "Account name must be 2–60 characters." });
    return;
  }

  const displayName = parsed.data.name.trim();
  const normalizedName = normalizeAccountName(displayName);
  try {
    await db
      .update(journalUsersTable)
      .set({ name: displayName, normalizedName })
      .where(eq(journalUsersTable.id, req.journalAuth!.user.id));
  } catch (error) {
    if (typeof error === "object" && error !== null && "code" in error && error.code === "23505") {
      res.status(409).json({ error: "That account name is already in use." });
      return;
    }
    throw error;
  }

  res.json(ChangeAccountNameResponse.parse({ user: { id: req.journalAuth!.user.id, name: displayName } }));
});

router.patch("/auth/pin", requireSession, async (req, res) => {
  const parsed = ChangeAccountPinBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "PINs must contain 4–6 digits." });
    return;
  }

  const auth = req.journalAuth!;
  const [user] = await db
    .select({ pinHash: journalUsersTable.pinHash })
    .from(journalUsersTable)
    .where(eq(journalUsersTable.id, auth.user.id))
    .limit(1);

  if (!user || !(await verifyPin(parsed.data.currentPin, user.pinHash))) {
    res.status(401).json({ error: "Current PIN is incorrect." });
    return;
  }

  await db
    .update(journalUsersTable)
    .set({ pinHash: await hashPin(parsed.data.newPin) })
    .where(eq(journalUsersTable.id, auth.user.id));
  await db
    .delete(journalSessionsTable)
    .where(and(eq(journalSessionsTable.userId, auth.user.id), ne(journalSessionsTable.id, auth.sessionId)));
  res.status(204).end();
});

export default router;
