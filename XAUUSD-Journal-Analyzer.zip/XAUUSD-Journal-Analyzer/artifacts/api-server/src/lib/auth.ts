import {
  createHash,
  createHmac,
  randomBytes,
  scrypt as scryptCallback,
  timingSafeEqual,
} from "node:crypto";
import type { RequestHandler } from "express";
import { and, eq, gt, sql } from "drizzle-orm";
import { db, journalSessionsTable, journalUsersTable, loginAttemptsTable } from "@workspace/db";

export const SESSION_COOKIE = "xau_journal_session";
export const SESSION_LIFETIME_MS = 30 * 24 * 60 * 60 * 1000;
const LOGIN_WINDOW_MS = 15 * 60 * 1000;
const LOGIN_BLOCK_MS = 15 * 60 * 1000;
const MAX_FAILED_ATTEMPTS = 5;
const INITIAL_USER_NAME = "Rizal";
const INITIAL_PIN_HASH =
  "scrypt$v1$ee0da546958365a1e17562dfc952583c$a658f2a922062129f3bda48e59ed9d286180424ad714d9085b51769a5e65e01a588d9422955e69c2e9fad0393f07fa164434b46b26bd3fd9a453900b1b9c1a66";

export interface JournalAuthContext {
  sessionId: string;
  user: { id: string; name: string };
}

declare global {
  namespace Express {
    interface Request {
      journalAuth?: JournalAuthContext;
    }
  }
}

function getSessionSecret() {
  const secret = process.env.SESSION_SECRET;
  if (!secret) throw new Error("SESSION_SECRET is required to issue or validate sessions.");
  return secret;
}

export function hashSessionToken(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

export function createSessionToken() {
  return randomBytes(32).toString("base64url");
}

export function getLoginBucketKey(name: string, ip: string) {
  return createHmac("sha256", getSessionSecret())
    .update(`login\u0000${ip}\u0000${name}`)
    .digest("hex");
}

function derivePinKey(pin: string, salt: string) {
  return new Promise<Buffer>((resolve, reject) => {
    scryptCallback(pin, salt, 64, (error, key) => {
      if (error) reject(error);
      else resolve(key as Buffer);
    });
  });
}

export async function hashPin(pin: string) {
  const salt = randomBytes(16).toString("hex");
  const derived = await derivePinKey(pin, salt);
  return `scrypt$v1$${salt}$${derived.toString("hex")}`;
}

export async function verifyPin(pin: string, encoded: string) {
  const match = /^scrypt\$v1\$([a-f0-9]{32})\$([a-f0-9]{128})$/.exec(encoded);
  if (!match) return false;
  const [, salt, expectedHex] = match;
  const expected = Buffer.from(expectedHex, "hex");
  const actual = await derivePinKey(pin, salt);
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}

export async function ensureInitialAccount() {
  const [existing] = await db.select({ id: journalUsersTable.id }).from(journalUsersTable).limit(1);
  if (existing) return;

  await db
    .insert(journalUsersTable)
    .values({
      name: INITIAL_USER_NAME,
      normalizedName: INITIAL_USER_NAME.toLocaleLowerCase(),
      pinHash: INITIAL_PIN_HASH,
    })
    .onConflictDoNothing();
}

export const DUMMY_PIN_HASH = INITIAL_PIN_HASH;

export async function getLoginRetryAfter(bucketKey: string, now = new Date()) {
  const [bucket] = await db
    .select({ blockedUntil: loginAttemptsTable.blockedUntil })
    .from(loginAttemptsTable)
    .where(eq(loginAttemptsTable.bucketKey, bucketKey))
    .limit(1);

  if (!bucket?.blockedUntil || bucket.blockedUntil <= now) return 0;
  return Math.max(1, Math.ceil((bucket.blockedUntil.getTime() - now.getTime()) / 1000));
}

export async function recordFailedLogin(bucketKey: string, now = new Date()) {
  const windowCutoff = new Date(now.getTime() - LOGIN_WINDOW_MS);
  const blockedUntil = new Date(now.getTime() + LOGIN_BLOCK_MS);
  const expiredWindow = sql`${loginAttemptsTable.windowStartedAt} <= ${windowCutoff}`;
  const nextFailureCount = sql`CASE WHEN ${expiredWindow} THEN 1 ELSE ${loginAttemptsTable.failedAttempts} + 1 END`;

  await db
    .insert(loginAttemptsTable)
    .values({ bucketKey, failedAttempts: 1, windowStartedAt: now })
    .onConflictDoUpdate({
      target: loginAttemptsTable.bucketKey,
      set: {
        failedAttempts: nextFailureCount,
        windowStartedAt: sql`CASE WHEN ${expiredWindow} THEN ${now} ELSE ${loginAttemptsTable.windowStartedAt} END`,
        blockedUntil: sql`CASE WHEN ${expiredWindow} THEN NULL WHEN ${nextFailureCount} >= ${MAX_FAILED_ATTEMPTS} THEN ${blockedUntil} ELSE ${loginAttemptsTable.blockedUntil} END`,
        updatedAt: now,
      },
    });

  return getLoginRetryAfter(bucketKey, now);
}

export async function clearLoginFailures(bucketKey: string) {
  await db.delete(loginAttemptsTable).where(eq(loginAttemptsTable.bucketKey, bucketKey));
}

export const requireSession: RequestHandler = async (req, res, next) => {
  try {
    const token = req.cookies?.[SESSION_COOKIE];
    if (typeof token !== "string" || token.length < 40 || token.length > 100) {
      res.status(401).json({ error: "Please sign in to continue." });
      return;
    }

    const now = new Date();
    const [session] = await db
      .select({
        sessionId: journalSessionsTable.id,
        userId: journalUsersTable.id,
        name: journalUsersTable.name,
      })
      .from(journalSessionsTable)
      .innerJoin(journalUsersTable, eq(journalSessionsTable.userId, journalUsersTable.id))
      .where(and(eq(journalSessionsTable.tokenHash, hashSessionToken(token)), gt(journalSessionsTable.expiresAt, now)))
      .limit(1);

    if (!session) {
      res.clearCookie(SESSION_COOKIE, { path: "/api", sameSite: "lax", secure: process.env.NODE_ENV === "production" });
      res.status(401).json({ error: "Please sign in to continue." });
      return;
    }

    req.journalAuth = {
      sessionId: session.sessionId,
      user: { id: session.userId, name: session.name },
    };
    next();
  } catch (error) {
    next(error);
  }
};
